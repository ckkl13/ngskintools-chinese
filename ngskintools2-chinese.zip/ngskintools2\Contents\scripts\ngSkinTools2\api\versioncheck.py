import datetime
import platform

from maya import cmds
from ngSkinTools2 import version
from ngSkinTools2.api import http_client
from ngSkinTools2.api.python_compatibility import Object


CHINESE_MANIFEST_URL = "https://raw.githubusercontent.com/ckkl13/ngskintools-chinese/main/update.json"


class ProviderUpdate(Object):
    def __init__(self, provider, current_version, latest_version, update_date, download_url, update_available, release_notes=""):
        self.provider = provider
        self.current_version = current_version
        self.latest_version = latest_version
        self.update_date = update_date
        self.download_url = download_url
        self.update_available = update_available
        self.release_notes = release_notes


class UpdateInfo(Object):
    def __init__(self):
        self.update_available = False
        self.providers = {}
        self.errors = {}


def download_update_info(success_callback, failure_callback):
    """
    executes version info download in separate thread,
    then runs provided callbacks in main thread when download completes or fails

    returns the update-check worker threads.
    """

    provider_results = {}
    provider_errors = {}
    pending = ["official", "chinese"]

    try:
        os_name = platform.system()
        maya_version = str(int(cmds.about(api=True)))
        official_url = http_client.encode_url(
            "https://versiondb.ngskintools.com/releases/ngSkinTools-v2-" + os_name + "-maya" + maya_version,
            {
                'currentVersion': version.pluginVersion(),
                'uniqueClientId': version.uniqueClientId(),
            },
        )
    except Exception as err:
        official_url = None
        provider_errors["official"] = str(err)
        pending.remove("official")

    def finish_if_ready():
        if pending:
            return

        info = UpdateInfo()
        info.providers = provider_results
        info.errors = provider_errors
        info.update_available = any(provider.update_available for provider in provider_results.values())

        if provider_results:
            success_callback(info)
        else:
            failure_callback("; ".join("{0}: {1}".format(key, value) for key, value in provider_errors.items()))

    def provider_failed(provider, error):
        provider_errors[provider] = str(error)
        pending.remove(provider)
        finish_if_ready()

    def provider_succeeded(provider, response):
        try:
            if provider == "official":
                update_date = datetime.datetime.strptime(response['dateReleased'], "%Y-%m-%d")
                latest_version = response['latestVersion']
                result = ProviderUpdate(
                    provider="official",
                    current_version=version.pluginVersion(),
                    latest_version=latest_version,
                    update_date=update_date,
                    download_url=response['downloadUrl'],
                    update_available=version.compare_semver(version.pluginVersion(), latest_version) > 0,
                )
            else:
                update_date = datetime.datetime.strptime(response['dateReleased'], "%Y-%m-%d")
                latest_version = response['latestVersion']
                result = ProviderUpdate(
                    provider="chinese",
                    current_version=version.chineseBuildVersion(),
                    latest_version=latest_version,
                    update_date=update_date,
                    download_url=response['downloadUrl'],
                    update_available=int(response['build']) > version.chineseBuildNumber(),
                    release_notes=response.get('releaseNotes', ''),
                )

            provider_results[provider] = result
        except Exception as err:
            provider_errors[provider] = str(err)

        pending.remove(provider)
        finish_if_ready()

    official_thread = None
    if official_url is not None:
        official_thread = http_client.get_async(
            official_url,
            success_callback=lambda response: provider_succeeded("official", response),
            failure_callback=lambda error: provider_failed("official", error),
            timeout=8,
        )
    chinese_thread = http_client.get_async(
        CHINESE_MANIFEST_URL,
        success_callback=lambda response: provider_succeeded("chinese", response),
        failure_callback=lambda error: provider_failed("chinese", error),
        timeout=8,
    )
    return official_thread, chinese_thread
