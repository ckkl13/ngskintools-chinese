# -*- coding: utf-8 -*-
from ngSkinTools2.ui.i18n import tr
from maya import OpenMayaUI as omui
from maya import cmds

from ngSkinTools2.api.log import getLogger
from ngSkinTools2.api.pyside import QtCore, QtGui, QtWidgets, QWidget, wrap_instance
from ngSkinTools2.api.session import session
from ngSkinTools2.ui import i18n
from ngSkinTools2.ui.options import config

from .. import cleanup, signal, version
from ..observableValue import ObservableValue
from ngSkinTools2.ui import aboutwindow, dialogs, hotkeys_setup, qt
from ngSkinTools2.ui import tabLayerEffects, tabMirror, tabPaint, tabSetWeights, tabTools
from ngSkinTools2.ui import targetui, updatewindow
from .layout import scale_multiplier

log = getLogger("main window")


def get_image_path(file_name):
    import os

    for i in os.getenv("XBMLANGPATH", "").split(os.path.pathsep):
        result = os.path.join(i, file_name)
        if os.path.isfile(result):
            return result

    return file_name


def build_menu(parent, actions):
    menu = QtWidgets.QMenuBar(parent=parent)

    def top_level_menu(label):
        sub_item = menu.addMenu(label)
        sub_item.setSeparatorsCollapsible(False)
        sub_item.setTearOffEnabled(True)
        return sub_item

    sub = top_level_menu(tr("文件"))
    sub.addSeparator().setText(tr("导入/导出"))
    sub.addAction(actions.importFile)
    sub.addAction(actions.exportFile)
    sub.addAction(actions.batch_skin_import_export)

    sub = top_level_menu(tr("图层"))
    sub.addSeparator().setText(tr("图层操作"))
    sub.addAction(actions.initialize)
    sub.addAction(actions.import_v1)
    actions.addLayersActions(sub)
    sub.addSeparator().setText(tr("复制"))
    sub.addAction(actions.transfer)

    sub = top_level_menu(tr("工具"))
    sub.addAction(actions.show_intensity_presets)
    sub.addSeparator()
    sub.addAction(actions.add_influences)
    sub.addAction(actions.toolsAssignFromClosestJoint)
    sub.addSeparator()
    sub.addAction(actions.transfer)
    sub.addSeparator()
    sub.addAction(actions.toolsDeleteCustomNodesOnSelection)
    sub.addAction(actions.toolsDeleteCustomNodes)

    sub = top_level_menu(tr("查看"))
    sub.addAction(actions.show_used_influences_only)
    decimals_menu = sub.addMenu(tr("强度小数位数"))
    decimals_menu.setTearOffEnabled(True)
    for decimals_action in actions.intensity_decimals_actions:
        decimals_menu.addAction(decimals_action)
    display_mode_menu = sub.addMenu(tr("影响物显示方式"))
    display_mode_menu.setTearOffEnabled(True)
    display_mode_menu.addAction(actions.influences_display_hierarchy)
    display_mode_menu.addAction(actions.influences_display_flat)

    sub = top_level_menu(tr("帮助"))
    sub.addAction(actions.documentation.user_guide)
    sub.addAction(actions.documentation.api_root)
    sub.addAction(actions.documentation.changelog)
    sub.addAction(actions.documentation.contact)
    sub.addSeparator()
    sub.addAction(actions.check_for_updates)
    sub.addAction(tr("关于...")).triggered.connect(lambda: aboutwindow.show(parent))

    sub = top_level_menu(tr("语言"))
    language_group = QtWidgets.QActionGroup(parent)
    language_group.setExclusive(False)
    language_actions = []

    def set_language_from_action(code):
        for action, action_language in language_actions:
            action.setChecked(action_language == code)
        i18n.set_language(code)

    for language, label, tooltip in (
        ("zh_CN", "简体中文", "切换界面语言为简体中文"),
        ("en_US", "English", "切换界面语言为英文"),
    ):
        language_action = QtWidgets.QAction(tr(label), parent)
        language_action.setCheckable(True)
        language_action.setChecked(i18n.current_language() == language)
        language_action.setToolTip(tr(tooltip))
        language_action.setStatusTip(tr(tooltip))
        language_action.triggered.connect(
            lambda _checked=False, code=language: set_language_from_action(code)
        )
        language_group.addAction(language_action)
        language_actions.append((language_action, language))
        sub.addAction(language_action)

    return menu


def build_rmb_menu_layers(view, actions):
    view.setContextMenuPolicy(QtCore.Qt.ActionsContextMenu)
    actions.addLayersActions(view)


class MainWindowOptions:
    current_tab = ObservableValue(0)


def build_ui(parent, run_initialization=True):
    """
    :type parent: QWidget
    """
    options = MainWindowOptions()
    window = QtWidgets.QWidget(parent)

    session.addQtWidgetReference(window)

    from ngSkinTools2.ui.actions import Actions

    actions = Actions(parent=window, session=session)

    tabs = QtWidgets.QTabWidget(window)

    tabs.addTab(tabPaint.build_ui(tabs, actions), tr("绘制"))
    tabs.addTab(tabSetWeights.build_ui(tabs), tr("设置权重"))
    tabs.addTab(tabMirror.build_ui(tabs), tr("镜像"))
    tabs.addTab(tabLayerEffects.build_ui(), tr("样式"))
    tabs.addTab(tabTools.build_ui(actions, session), tr("工具"))

    @signal.on(options.current_tab.changed)
    def set_current_tab():
        tabs.setCurrentIndex(options.current_tab())

    tabs.currentChanged.connect(options.current_tab.set)
    set_current_tab()

    layers_toolbar = QtWidgets.QToolBar()
    layers_toolbar.addAction(actions.addLayer)
    layers_toolbar.setOrientation(QtCore.Qt.Vertical)

    spacing_h = 5
    spacing_v = 5

    layers_row = targetui.build_target_ui(window, actions, session)

    split = QtWidgets.QSplitter(orientation=QtCore.Qt.Vertical, parent=window)
    split.addWidget(layers_row)
    split.addWidget(tabs)
    split.setStretchFactor(0, 2)
    split.setStretchFactor(1, 3)
    split.setContentsMargins(spacing_h, spacing_v, spacing_h, spacing_v)

    def build_icon_label():
        w = QWidget()
        w.setStyleSheet("background-color: #dcce87;color: #373737;")
        l = QtWidgets.QHBoxLayout()
        icon = QtWidgets.QLabel()
        icon.setPixmap(QtGui.QIcon(":/error.png").pixmap(16 * scale_multiplier, 16 * scale_multiplier))
        icon.setFixedSize(16 * scale_multiplier, 16 * scale_multiplier)
        text = QtWidgets.QLabel("<placeholder>")
        text.setWordWrap(True)
        text.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)

        l.addWidget(icon)
        l.addWidget(text)
        w.setContentsMargins(0, 0, 0, 0)
        w.setLayout(l)

        return w, text.setText

    layout = QtWidgets.QVBoxLayout(window)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.addWidget(build_menu(window, actions))
    layout.addWidget(split)

    window.setLayout(layout)

    if run_initialization:
        hotkeys_setup.install_hotkeys()

    dialogs.promptsParent = window

    if run_initialization and config.checkForUpdatesAtStartup():
        updatewindow.silent_check_and_show_if_available(qt.mainWindow)

    return window, options


DOCK_NAME = 'ngSkinTools2_mainWindow'
_workspace_widget = None
_main_ui = None
_language_listener = None


def _rebuild_main_ui():
    global _main_ui
    if _workspace_widget is None or _workspace_widget.layout() is None:
        return

    if _main_ui is not None:
        tabs = _main_ui.findChild(QtWidgets.QTabWidget)
        if tabs is not None:
            MainWindowOptions.current_tab.set(tabs.currentIndex())
        _workspace_widget.layout().removeWidget(_main_ui)
        _main_ui.hide()
        _main_ui.setParent(None)
        _main_ui.deleteLater()

    _main_ui, _ = build_ui(_workspace_widget, run_initialization=False)
    _workspace_widget.layout().addWidget(_main_ui)


def _refresh_batch_import_export_dialog_if_open():
    app = QtWidgets.QApplication.instance()
    if app is None:
        return

    for widget in app.allWidgets():
        try:
            is_batch_dialog = (
                widget.objectName() == "ngBatchImportDialog" and widget.isVisible()
            )
        except RuntimeError:
            is_batch_dialog = False

        if is_batch_dialog:
            from ngSkinTools2.ui.actions import show_batch_skin_import_export_dialog

            show_batch_skin_import_export_dialog(force_rebuild=True)
            return


def workspace_control_permanent_script():
    from ngSkinTools2 import workspace_control_main_window

    return "import {f.__module__}; {f.__module__}.{f.__name__}()".format(f=workspace_control_main_window)


# noinspection PyShadowingBuiltins
def open():
    """
    opens main window
    """

    if not cmds.workspaceControl(DOCK_NAME, q=True, exists=True):
        # build UI script in type-safe manner

        cmds.workspaceControl(
            DOCK_NAME,
            retain=False,
            floating=True,
            # ttc=["AttributeEditor",-1],
            uiScript=workspace_control_permanent_script(),
        )

    # bring tab to front
    cmds.evalDeferred(lambda *args: cmds.workspaceControl(DOCK_NAME, e=True, r=True))

    def close():
        from maya import cmds

        # noinspection PyBroadException
        try:
            cmds.deleteUI(DOCK_NAME)
        except:
            pass
        pass

    cleanup.registerCleanupHandler(close)


def resume_in_workspace_control():
    """
    this method is responsible for resuming workspace control when Maya is building/restoring UI as part of it's
    workspace management cycle (open UI for the first time, restart maya, change workspace, etc)
    """

    global _workspace_widget, _main_ui, _language_listener
    cmds.workspaceControl(DOCK_NAME, e=True, label="ngSkinTools " + version.pluginVersion())
    widget = wrap_instance(omui.MQtUtil.findControl(DOCK_NAME), QtWidgets.QWidget)

    _workspace_widget = widget
    _main_ui, _ = build_ui(widget)
    widget.layout().addWidget(_main_ui)

    if _language_listener is not None:
        i18n.unregister_language_listener(_language_listener)

    def on_language_changed(_language):
        cmds.inViewMessage(amg=i18n.tr("界面语言已切换"), pos="topCenter", fade=True)
        _refresh_batch_import_export_dialog_if_open()
        cmds.evalDeferred(_rebuild_main_ui)

    _language_listener = on_language_changed
    i18n.register_language_listener(_language_listener)
