# -*- coding: utf-8 -*-
from ngSkinTools2.ui.i18n import tr
from ngSkinTools2 import signal
from ngSkinTools2.api.pyside import QtCore, QtWidgets
from ngSkinTools2.ui import qt
from ngSkinTools2.ui.options import config


DEFAULT_INTENSITY_PRESETS = [0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0]


def clamp_intensity(value):
    return max(0.0, min(1.0, float(value)))


class IntensityPresets(QtWidgets.QWidget):
    def __init__(self, parent, value_getter, value_setter, on_applied=None):
        super(IntensityPresets, self).__init__(parent)
        self._value_getter = value_getter
        self._value_setter = value_setter
        self._on_applied = on_applied
        self._buttons = []
        self._layout = QtWidgets.QHBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(10)
        self._layout.setAlignment(QtCore.Qt.AlignLeft)
        self._rebuild()

        @signal.on(config.paint_intensity_presets.changed, qtParent=self)
        def presets_changed():
            self._rebuild()

        @signal.on(config.paint_intensity_decimals.changed, qtParent=self)
        def decimals_changed():
            self._rebuild()

        @signal.on(config.show_paint_intensity_presets.changed, qtParent=self)
        def visibility_changed():
            self.setVisible(config.show_paint_intensity_presets())

        self.setVisible(config.show_paint_intensity_presets())

    def _rebuild(self):
        for button in self._buttons:
            self._layout.removeWidget(button)
            button.deleteLater()
        self._buttons = []
        for index, value in enumerate(config.paint_intensity_presets()):
            button = QtWidgets.QPushButton(
                ("{0:.%dg}" % config.paint_intensity_decimals()).format(value), self
            )
            button.setStyleSheet("padding: 0px;")
            button.setSizePolicy(
                QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Preferred
            )
            button.adjustSize()
            button.clicked.connect(lambda _checked=False, v=value: self._apply(v))
            button.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            button.customContextMenuRequested.connect(
                lambda _pos, i=index: self._edit(i)
            )
            self._layout.addWidget(button)
            self._buttons.append(button)

        if self._buttons:
            button_width = max(button.sizeHint().width() for button in self._buttons)
            for button in self._buttons:
                button.setFixedWidth(button_width)

    def _apply(self, value):
        self._value_setter(clamp_intensity(value))
        if self._on_applied is not None:
            self._on_applied()

    def _edit(self, index):
        presets = list(config.paint_intensity_presets())
        value, accepted = QtWidgets.QInputDialog.getDouble(
            self,
            tr("编辑强度预设"),
            tr("强度:"),
            presets[index],
            0.0,
            1.0,
            config.paint_intensity_decimals(),
        )
        if accepted:
            presets[index] = clamp_intensity(value)
            config.paint_intensity_presets.set(presets)


def create(parent, value_getter, value_setter, on_applied=None):
    return IntensityPresets(parent, value_getter, value_setter, on_applied)
