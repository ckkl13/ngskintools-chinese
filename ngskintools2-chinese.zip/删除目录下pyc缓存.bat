@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem Generic Python cache cleaner.
rem It only cleans the folder containing this .bat file and its subfolders.
set "ROOT=%~dp0"
set /a CACHE_DIRS=0
set /a PYC_FILES=0
set /a FAILURES=0

echo Cleaning Python cache under:
echo %ROOT%
echo.

rem Remove complete __pycache__ folders first, including their contents.
for /d /r "%ROOT%" %%D in (__pycache__) do (
    if exist "%%~fD\" (
        echo [DIR] %%~fD
        rd /s /q "%%~fD"
        if exist "%%~fD\" (
            echo [FAIL] %%~fD
            set /a FAILURES+=1
        ) else (
            set /a CACHE_DIRS+=1
        )
    )
)

rem Remove legacy .pyc files stored outside __pycache__ folders.
for /r "%ROOT%" %%F in (*.pyc) do (
    if exist "%%~fF" (
        echo [PYC] %%~fF
        del /f /q "%%~fF" >nul 2>&1
        if exist "%%~fF" (
            echo [FAIL] %%~fF
            set /a FAILURES+=1
        ) else (
            set /a PYC_FILES+=1
        )
    )
)

echo.
echo Finished. Removed !CACHE_DIRS! __pycache__ folder(s) and !PYC_FILES! loose .pyc file(s).
if not "!FAILURES!"=="0" (
    echo !FAILURES! item(s) could not be removed. Close Maya or other Python processes and try again.
    pause
    exit /b 1
)

echo Only __pycache__ folders and .pyc files were removed.
pause
exit /b 0
