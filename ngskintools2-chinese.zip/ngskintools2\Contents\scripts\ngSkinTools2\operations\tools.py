# -*- coding: UTF-8 -*-

from ngSkinTools2.ui.i18n import tr
from maya import cmds

from ngSkinTools2 import api, signal
from ngSkinTools2.api.layers import generate_layer_name
from ngSkinTools2.api.log import getLogger
from ngSkinTools2.api.pyside import QtWidgets
from ngSkinTools2.api.python_compatibility import Object
from ngSkinTools2.api.session import Session
from ngSkinTools2.decorators import undoable
from ngSkinTools2.observableValue import ObservableValue
from ngSkinTools2.operations import layers
from ngSkinTools2.operations.affected_vertices import affected_vertex_indexes
from ngSkinTools2.ui import dialogs
from ngSkinTools2.ui.options import config

logger = getLogger("operation/tools")


def __create_tool_action__(parent, session, action_name, action_tooltip, exec_handler, enabled_handler=None):
    """
    :type session: Session
    """

    from ngSkinTools2.ui import actions

    def execute():
        if not session.active():
            return

        exec_handler()

    result = actions.define_action(parent, action_name, callback=execute, tooltip=action_tooltip)

    @signal.on(session.events.targetChanged, session.events.currentLayerChanged)
    def update_state():
        enabled = session.state.layersAvailable and session.state.currentLayer.layer is not None
        if enabled and enabled_handler is not None:
            enabled = enabled_handler(session.state.currentLayer.layer)
        result.setEnabled(enabled)

    update_state()

    return result


class ClosestJointOptions(Object):
    def __init__(self):
        self.create_new_layer = ObservableValue(False)
        self.all_influences = ObservableValue(True)


def create_action__from_closest_joint(parent, session):
    options = ClosestJointOptions()

    def exec_handler():
        layer = session.state.currentLayer.layer
        influences = None
        if not options.all_influences():
            influences = layer.paint_targets
            if not influences:
                dialogs.info(tr("在影响物列表中选择一个或多个影响影响物"))
                return

        if options.create_new_layer():
            layer = layers.addLayer()

        api.assign_from_closest_joint(
            session.state.selectedSkinCluster,
            layer,
            influences=influences,
        )
        session.events.currentLayerChanged.emitIfChanged()
        session.events.influencesListUpdated.emit()

        if layer.paint_target is None:
            used_influences = layer.get_used_influences()
            if used_influences:
                layer.paint_target = min(used_influences)

    return (
        __create_tool_action__(
            parent,
            session,
            action_name=tr(u"从最近的关节分配"),
            action_tooltip=tr("为所选图层中每个顶点的最接近影响物分配1.0权重"),
            exec_handler=exec_handler,
        ),
        options,
    )


class UnifyWeightsOptions(Object):
    overall_effect = ObservableValue(1.0)
    single_cluster_mode = ObservableValue(False)


def create_action__unify_weights(parent, session):
    options = UnifyWeightsOptions()

    def exec_handler():
        api.unify_weights(
            session.state.selectedSkinCluster,
            session.state.currentLayer.layer,
            overall_effect=options.overall_effect(),
            single_cluster_mode=options.single_cluster_mode(),
        )

    return (
        __create_tool_action__(
            parent,
            session,
            action_name=tr(u"统一权重"),
            action_tooltip=tr("对于选定的顶点，使所有顶点的顶点都相同"),
            exec_handler=exec_handler,
        ),
        options,
    )


def create_action__merge_layers(parent, session):
    """
    :param parent: UI parent for this action
    :type session: Session
    """

    def exec_handler():
        api.merge_layers(layers=session.context.selected_layers(default=[]))
        session.events.layerListChanged.emitIfChanged()
        session.events.currentLayerChanged.emitIfChanged()

    def enabled_handler(layer):
        return layer is not None and layer.index > 0

    return __create_tool_action__(
        parent,
        session,
        action_name=tr(u"合并"),
        action_tooltip=tr("将这一层的内容合并到底层,预效果权重将用于此"),
        exec_handler=exec_handler,
        enabled_handler=enabled_handler,
    )


def create_action__duplicate_layer(parent, session):
    """
    :param parent: UI parent for this action
    :type session: Session
    """

    @undoable
    def exec_handler():
        with api.suspend_updates(session.state.selectedSkinCluster):
            for source in session.context.selected_layers(default=[]):
                api.duplicate_layer(layer=source, copy_suffix=tr(u"副本"))

        session.events.layerListChanged.emitIfChanged()
        session.events.currentLayerChanged.emitIfChanged()

    return __create_tool_action__(
        parent,
        session,
        action_name=tr(u"复制"),
        action_tooltip=tr("复制所选图层"),
        exec_handler=exec_handler,
    )


def create_action__fill_transparency(parent, session):
    """
    :param parent: UI parent for this action
    :type session: Session
    """

    @undoable
    def exec_handler():
        with api.suspend_updates(session.state.selectedSkinCluster):
            for source in session.context.selected_layers(default=[]):
                api.fill_transparency(layer=source)

    return __create_tool_action__(
        parent,
        session,
        action_name=tr(u"填充透明度"),
        action_tooltip=tr("所选图层中的所有透明顶点都从其最近的非空相邻顶点接收权重"),
        exec_handler=exec_handler,
    )


def create_action__copy_component_weights(parent, session):
    """
    :param parent: UI parent for this action
    :type session: Session
    """

    def exec_handler():
        for source in session.context.selected_layers(default=[]):
            api.copy_component_weights(layer=source)

    return __create_tool_action__(
        parent,
        session,
        action_name=tr(u"复制组件权重"),
        action_tooltip=tr("在内存中存储组件权重，以便进行基于组件的后续粘贴操作"),
        exec_handler=exec_handler,
    )


def create_action__paste_average_component_weight(parent, session):
    """
    :param parent: UI parent for this action
    :type session: Session
    """

    def exec_handler():
        for l in session.context.selected_layers(default=[]):
            api.paste_average_component_weights(layer=l)

    return __create_tool_action__(
        parent,
        session,
        action_name=tr(u"给予平均组件权重"),
        action_tooltip=tr("计算复制组件权重的平均值，并将该值设置为当前选择的组件"),
        exec_handler=exec_handler,
    )


def create_action__add_influences(parent, session):
    """
    :param parent: UI parent for this action
    :type session: Session
    """

    def exec_handler():
        selection = cmds.ls(sl=True, l=True)
        if len(selection) < 2:
            logger.info(tr("无效选择: %s"), selection)
            return
        api.add_influences(selection[:-1], selection[-1])
        cmds.select(selection[-1])
        session.events.influencesListUpdated.emit()

    return __create_tool_action__(
        parent,
        session,
        action_name=tr(u"添加影响物"),
        action_tooltip=tr("将选定的影响物添加到当前皮肤簇"),
        exec_handler=exec_handler,
    )


def get_selected_skinned_models():
    selected = cmds.ls(selection=True, objectsOnly=True, long=True) or []
    result = []
    for target in selected:
        try:
            if api.get_related_skin_cluster(target) is not None and target not in result:
                result.append(target)
        except Exception:
            continue
    return result


@undoable
def apply_limit_weights(targets, influence_count):
    for target in targets:
        target_layers = api.init_layers(target)
        layer_name = generate_layer_name(target_layers.list(), tr("限制权重"))
        target_layers.add(layer_name)
        target_layers.influence_limit_per_vertex = influence_count


def create_action__limit_weights(parent, session):
    from ngSkinTools2.ui import actions

    def execute():
        targets = get_selected_skinned_models()
        if not targets:
            return

        influence_count, accepted = QtWidgets.QInputDialog.getInt(
            parent,
            tr("限制权重"),
            tr("每个顶点最大影响物数量:"),
            int(config.limit_weights_count()),
            1,
            65535,
            1,
        )
        if not accepted:
            return

        try:
            apply_limit_weights(targets, influence_count)
        except Exception as err:
            dialogs.displayError(str(err))
            return

        config.limit_weights_count.set(influence_count)
        session.events.targetChanged.emitIfChanged()
        session.events.layerListChanged.emitIfChanged()

    result = actions.define_action(
        parent,
        tr("限制权重..."),
        callback=execute,
        tooltip=tr("为所选网格创建限制权重图层，并设置每个顶点的最大影响物数量"),
    )

    @signal.on(session.events.nodeSelectionChanged)
    def update_enabled():
        result.setEnabled(bool(get_selected_skinned_models()))

    update_enabled()
    return result


@undoable
def apply_prune_weights(targets, threshold):
    for target in targets:
        target_layers = api.init_layers(target)
        layer_name = generate_layer_name(target_layers.list(), tr("修剪权重"))
        target_layers.add(layer_name)
        target_layers.prune_weights_filter_threshold = threshold


def create_action__prune_weights(parent, session):
    from ngSkinTools2.ui import actions

    def execute():
        targets = get_selected_skinned_models()
        if not targets:
            return

        threshold, accepted = QtWidgets.QInputDialog.getDouble(
            parent,
            tr("修剪小权重"),
            tr("修剪小权重阈值:"),
            float(config.prune_weights_threshold()),
            0.000001,
            0.05,
            6,
        )
        if not accepted:
            return

        try:
            apply_prune_weights(targets, threshold)
        except Exception as err:
            dialogs.displayError(str(err))
            return

        config.prune_weights_threshold.set(threshold)
        session.events.targetChanged.emitIfChanged()
        session.events.layerListChanged.emitIfChanged()

    result = actions.define_action(
        parent,
        tr("修剪小权重..."),
        callback=execute,
        tooltip=tr("为所选网格创建修剪权重图层，并设置小权重阈值"),
    )

    @signal.on(session.events.nodeSelectionChanged)
    def update_enabled():
        result.setEnabled(bool(get_selected_skinned_models()))

    update_enabled()
    return result


def select_affected_vertices(session, influences):
    """Select mesh vertices affected by the explicit influence IDs."""
    selected_layers = session.context.selected_layers(default=[])
    if not selected_layers or not influences:
        return

    affected_indexes = set()
    for influence_id in influences:
        affected_indexes.update(
            affected_vertex_indexes(selected_layers, influence_id)
        )

    if not affected_indexes:
        return

    current_selection = cmds.ls(sl=True, o=True, l=True) or []
    selected_mesh_probably = current_selection[0] if len(current_selection) == 1 else None
    if selected_mesh_probably is None:
        skin_cluster = session.state.selectedSkinCluster
        geometries = cmds.skinCluster(skin_cluster, q=True, g=True) if skin_cluster else []
        if geometries:
            selected_mesh_probably = geometries[0]
    if selected_mesh_probably is None:
        return
    vertices = [
        selected_mesh_probably + ".vtx[%d]" % index
        for index in sorted(affected_indexes)
    ]
    try:
        cmds.select(vertices)
    except Exception as err:
        logger.warning("failed to select affected vertices: %s", err)


def create_action__select_affected_vertices(parent, session):
    """
    :param parent: UI parent for this action
    :type session: Session
    """

    def exec_handler():
        layer = session.state.currentLayer.layer
        if layer is None:
            return
        select_affected_vertices(session, layer.paint_targets)

    return __create_tool_action__(
        parent,
        session,
        action_name=tr(u"选择受影响的顶点"),
        action_tooltip=tr("选择对当前影响物具有非零权重的顶点"),
        exec_handler=exec_handler,
    )
