# -*- coding: UTF-8 -*-


def update_locked_influences(existing_ids, skin_influence_ids, lock):
    """Return locked influence ids after applying one skinCluster-wide action."""
    existing = list(existing_ids or [])
    targets = list(skin_influence_ids or [])

    if lock:
        result = list(existing)
        for influence_id in targets:
            if influence_id not in result:
                result.append(influence_id)
        return result

    targets = set(targets)
    return [
        influence_id
        for influence_id in existing
        if influence_id not in targets
    ]


def inverse_influence_ids(selected_ids, skin_influence_ids):
    """Return skin influence ids not present in a non-empty selection."""
    selected = set(selected_ids or [])
    if not selected:
        return []
    return [influence_id for influence_id in (skin_influence_ids or []) if influence_id not in selected]


def toggle_locked_influences(existing_ids, clicked_id, selected_ids):
    """Toggle the clicked influence and its current selection as one group."""
    existing = list(existing_ids or [])
    selected = list(selected_ids or [])
    targets = selected if clicked_id in selected else [clicked_id]
    should_lock = clicked_id not in existing
    return update_locked_influences(existing, targets, should_lock), targets


def apply_skin_cluster_influence_lock(layer, influences, lock):
    """Update one ngSkinTools layer from a skinCluster influence list."""
    if layer is None:
        return False

    updated = update_locked_influences(
        layer.locked_influences,
        [
            influence.logicalIndex
            for influence in (influences or [])
        ],
        lock,
    )
    if list(layer.locked_influences or []) == updated:
        return False

    layer.locked_influences = updated
    return True


def apply_inverse_skin_cluster_influence_lock(layer, influences, selected_ids, lock):
    """Apply a lock action to the influences outside the current selection."""
    if layer is None:
        return False

    influence_ids = [influence.logicalIndex for influence in (influences or [])]
    targets = inverse_influence_ids(selected_ids, influence_ids)
    if not targets:
        return False

    updated = update_locked_influences(layer.locked_influences, targets, lock)
    if list(layer.locked_influences or []) == updated:
        return False

    layer.locked_influences = updated
    return True
