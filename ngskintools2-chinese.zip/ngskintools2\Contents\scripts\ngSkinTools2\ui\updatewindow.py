# -*- coding: utf-8 -*-
from ngSkinTools2.ui.i18n import tr
import webbrowser

from ngSkinTools2.api import versioncheck
from ngSkinTools2.api.log import getLogger
from ngSkinTools2.api.pyside import Qt, QtWidgets
from ngSkinTools2.ui.options import bind_checkbox, config

from .. import cleanup, signal, version
from . import qt
from .layout import scale_multiplier

log = getLogger("plugin")


def show(parent, silent_mode):
    """
    :type parent: QWidget
    """

    error_signal = signal.Signal("error")
    success_signal = signal.Signal("success")

    # noinspection PyShadowingNames
    def body():
        result = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout()
        result.setLayout(layout)
        layout.setContentsMargins(20, 30, 20, 20)

        header = QtWidgets.QLabel(tr("<strong>正在检查更新...</strong>"))
        layout.addWidget(header)

        provider_widgets = {}

        def add_provider_group(provider, title):
            group = QtWidgets.QGroupBox(tr(title))
            group_layout = QtWidgets.QVBoxLayout()
            group.setLayout(group_layout)

            status = QtWidgets.QLabel(tr("<strong>正在检查更新...</strong>"))
            current = QtWidgets.QLabel()
            latest = QtWidgets.QLabel()
            notes = QtWidgets.QLabel()
            notes.setWordWrap(True)
            download = QtWidgets.QPushButton(tr("下载更新"))
            for widget in (current, latest, notes, download):
                widget.setVisible(False)

            def open_download(checked=False, button=download):
                url = button.property("downloadUrl")
                if url:
                    webbrowser.open_new(str(url))

            download.clicked.connect(open_download)
            group_layout.addWidget(status)
            group_layout.addWidget(current)
            group_layout.addWidget(latest)
            group_layout.addWidget(notes)
            group_layout.addWidget(download)
            layout.addWidget(group)

            provider_widgets[provider] = {
                "status": status,
                "current": current,
                "latest": latest,
                "notes": notes,
                "download": download,
            }

        add_provider_group("official", "原版官网")
        add_provider_group("chinese", "中文版")

        @signal.on(error_signal)
        def error_handler(error):
            header.setText(u"<strong>{0}</strong>".format(tr("检查更新失败")))
            for provider_ui in provider_widgets.values():
                provider_ui["status"].setText(tr("检查失败：{0}").format(error))

        @signal.on(success_signal)
        def success_handler(info):
            """

            :type info: ngSkinTools2.api.versioncheck.
            """

            if info.update_available:
                header.setText(u"<strong>{0}</strong>".format(tr("发现可用更新！")))
            elif info.errors:
                header.setText(u"<strong>{0}</strong>".format(tr("部分更新源检查失败")))
            else:
                header.setText(u"<strong>{0}</strong>".format(tr("ngSkinTools 已是最新版本。")))

            for provider, provider_ui in provider_widgets.items():
                provider_info = info.providers.get(provider)
                if provider_info is None:
                    provider_ui["status"].setText(
                        tr("检查失败：{0}").format(info.errors.get(provider, tr("未知错误")))
                    )
                    continue

                provider_ui["current"].setVisible(True)
                provider_ui["current"].setText(
                    tr("当前版本：<strong>{0}</strong>").format(provider_info.current_version)
                )
                if provider_info.update_available:
                    provider_ui["status"].setText(tr("发现可用更新！"))
                    provider_ui["latest"].setVisible(True)
                    provider_ui["latest"].setText(
                        tr("可用更新：<strong>{0}</strong>，发布日期：{1}").format(
                            provider_info.latest_version,
                            provider_info.update_date.strftime("%Y-%m-%d"),
                        )
                    )
                    if provider_info.release_notes:
                        provider_ui["notes"].setVisible(True)
                        provider_ui["notes"].setText(tr("更新说明：{0}").format(provider_info.release_notes))
                    provider_ui["download"].setText(tr("下载更新") + " " + provider_info.latest_version)
                    provider_ui["download"].setProperty("downloadUrl", provider_info.download_url)
                    provider_ui["download"].setVisible(True)
                else:
                    provider_ui["status"].setText(tr("已是最新版本"))

        return result

    # noinspection PyShadowingNames
    def buttonsRow(window):
        btn_close = QtWidgets.QPushButton(tr("关闭"))
        btn_close.setMinimumWidth(100 * scale_multiplier)

        check_do_on_startup = bind_checkbox(QtWidgets.QCheckBox(tr("启动时检查更新")), config.checkForUpdatesAtStartup)

        layout = QtWidgets.QHBoxLayout()
        layout.addWidget(check_do_on_startup)
        layout.addStretch()
        layout.addWidget(btn_close)
        layout.setContentsMargins(20 * scale_multiplier, 15 * scale_multiplier, 20 * scale_multiplier, 15 * scale_multiplier)

        btn_close.clicked.connect(lambda: window.close())
        return layout

    window = QtWidgets.QWidget(parent, Qt.Window | Qt.WindowTitleHint | Qt.CustomizeWindowHint)
    window.resize(440 * scale_multiplier, 340 * scale_multiplier)
    window.setAttribute(Qt.WA_DeleteOnClose)
    window.setWindowTitle(tr("ngSkinTools2 版本更新"))
    layout = QtWidgets.QVBoxLayout()
    window.setLayout(layout)
    layout.setContentsMargins(0, 0, 0, 0)

    layout.addWidget(body())
    layout.addStretch(2)
    layout.addLayout(buttonsRow(window))

    if not silent_mode:
        window.show()

    @signal.on(success_signal)
    def on_success(info):
        if silent_mode:
            if info.update_available:
                window.show()
            else:
                log.info("not showing the window")
                window.close()

    cleanup.registerCleanupHandler(window.close)

    @qt.on(window.destroyed)
    def closed():
        log.info("deleting update window")

    versioncheck.download_update_info(success_callback=success_signal.emit, failure_callback=error_signal.emit)


def silent_check_and_show_if_available(parent):
    show(parent, silent_mode=True)


def show_and_start_update(parent):
    show(parent, silent_mode=False)


def build_action_check_for_updates(parent):
    from ngSkinTools2.ui import actions

    return actions.define_action(parent, tr("检查更新..."), callback=lambda: show_and_start_update(parent))
