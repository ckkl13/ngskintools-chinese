# -*- coding: UTF-8 -*-

from ngSkinTools2.ui.i18n import tr
from ngSkinTools2 import signal
from ngSkinTools2.api import influence_names
from ngSkinTools2.api.influenceMapping import InfluenceInfo
from ngSkinTools2.api.layers import Layer
from ngSkinTools2.api.log import getLogger
from ngSkinTools2.api.pyside import QActionGroup, QtCore, QtGui, QtWidgets
from ngSkinTools2.api.target_info import list_influences
from ngSkinTools2.operations.affected_vertices import context_influence_id
from ngSkinTools2.operations.tools import select_affected_vertices
from ngSkinTools2.ui import actions, qt
from ngSkinTools2.ui.influence_locking import (
    apply_inverse_skin_cluster_influence_lock,
    apply_skin_cluster_influence_lock,
    toggle_locked_influences,
)
from ngSkinTools2.ui.influence_tree_state import (
    SearchTransition,
    apply_expansion_policy,
    capture_tree_snapshot,
    descendant_items,
    drop_duplicate_dag_paths,
    first_existing_target,
    is_branch_indicator_hit,
    is_recursive_toggle_request,
    prepare_display_records,
    resolve_unique_dag_paths,
    restore_tree_snapshot,
    reveal_item,
    sample_influence_reveal_state,
    set_branch_expanded,
)
from ngSkinTools2.ui.layout import scale_multiplier
from ngSkinTools2.ui.options import Config, config

log = getLogger("influencesView")
_ = Layer  # only imported for type reference


class RecursiveBranchToggleFilter(QtCore.QObject):
    """Handle Ctrl+Shift+left-click on a tree disclosure indicator."""

    def __init__(self, view):
        super(RecursiveBranchToggleFilter, self).__init__(view)
        self.view = view

    @staticmethod
    def item_depth(item):
        depth = 0
        parent_item = item.parent()
        while parent_item is not None:
            depth += 1
            parent_item = parent_item.parent()
        return depth

    @staticmethod
    def event_position(event):
        position = getattr(event, "position", None)
        if position is not None:
            return position().toPoint()
        return event.pos()

    def eventFilter(self, watched, event):
        if event.type() != QtCore.QEvent.MouseButtonPress:
            return QtCore.QObject.eventFilter(self, watched, event)

        if not is_recursive_toggle_request(
            event.button(),
            event.modifiers(),
            QtCore.Qt.LeftButton,
            QtCore.Qt.ControlModifier,
            QtCore.Qt.ShiftModifier,
        ):
            return QtCore.QObject.eventFilter(self, watched, event)

        position = self.event_position(event)
        item = self.view.itemAt(position)
        if item is None or item.childCount() == 0:
            return QtCore.QObject.eventFilter(self, watched, event)

        tree_column = self.view.treePosition()
        column_left = self.view.header().sectionViewportPosition(tree_column)
        if not is_branch_indicator_hit(
            position.x(),
            self.item_depth(item),
            self.view.indentation(),
            column_left,
        ):
            return QtCore.QObject.eventFilter(self, watched, event)

        with qt.signals_blocked(self.view):
            set_branch_expanded(item, not item.isExpanded())

        self.view.viewport().update()
        event.accept()
        return True


class InfluenceTree(QtWidgets.QTreeWidget):
    """Influence list that never scrolls as a side effect of selection."""

    def __init__(self, parent=None):
        super(InfluenceTree, self).__init__(parent)
        self._allow_reveal_scroll = False

    def scrollTo(self, index, hint=QtWidgets.QAbstractItemView.EnsureVisible):
        if not self._allow_reveal_scroll:
            return
        return super(InfluenceTree, self).scrollTo(index, hint)

    def resizeEvent(self, event):
        super(InfluenceTree, self).resizeEvent(event)
        for callback_name in (
            "_name_column_resize_callback",
            "_frozen_header_resize_callback",
        ):
            callback = getattr(self, callback_name, None)
            if callback is not None:
                QtCore.QTimer.singleShot(0, callback)


class FrozenInfluenceHeader(QtWidgets.QWidget):
    """Keep the influence column title visible while the body scrolls."""

    def __init__(self, view, parent=None):
        super(FrozenInfluenceHeader, self).__init__(parent or view)
        self.view = view
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
        self.setObjectName("ngSkinTools2FrozenInfluenceHeader")

    def paintEvent(self, event):
        header = self.view.header()
        palette = header.palette()
        painter = QtGui.QPainter(self)
        painter.setClipRect(event.rect())
        painter.fillRect(event.rect(), palette.color(QtGui.QPalette.Button))
        painter.setPen(palette.color(QtGui.QPalette.ButtonText))
        painter.setFont(header.font())
        title = self.view.headerItem().text(1) if self.view.headerItem() else tr("影响物")
        painter.drawText(
            self.rect().adjusted(8, 0, -4, 0),
            QtCore.Qt.AlignVCenter | QtCore.Qt.AlignLeft,
            title,
        )
        painter.setPen(palette.color(QtGui.QPalette.Mid))
        painter.drawLine(self.width() - 1, 0, self.width() - 1, self.height())


def build_used_influences_action(parent):
    def toggle():
        config.influences_show_used_influences_only.set(not config.influences_show_used_influences_only())

    result = actions.define_action(
        parent,
        tr("只显示有权重的影响物"),
        callback=toggle,
        tooltip=tr("如果启用，“影响”视图将只显示当前层上具有权重的影响"),
    )

    @signal.on(config.influences_show_used_influences_only.changed, qtParent=parent)
    def update():
        result.setChecked(config.influences_show_used_influences_only())

    result.setCheckable(True)
    update()
    return result


def build_set_influences_sorted_action(parent):
    from ngSkinTools2.ui import actions

    def toggle():
        new_value = Config.InfluencesSortDescending
        if config.influences_sort() == new_value:
            new_value = Config.InfluencesSortUnsorted
        config.influences_sort.set(new_value)

    result = actions.define_action(
        parent,
        tr("影响物排序 ( 按名称 )"),
        callback=toggle,
        tooltip=tr("按名称对影响进行排序"),
    )

    @signal.on(config.influences_sort.changed, qtParent=parent)
    def update():
        result.setChecked(config.influences_sort() == Config.InfluencesSortDescending)

    result.setCheckable(True)
    update()
    return result


def build_influences_display_mode_actions(parent):
    """Build a persistent hierarchy/flat display mode pair."""

    group = QActionGroup(parent)
    # Keep the same checkbox indicator as other checkable menu actions
    # (for example, tr("启用选中图层")).  The selected mode is still kept
    # mutually exclusive by the config-backed update callback below.
    group.setExclusive(False)

    hierarchy_action = actions.define_action(
        parent,
        tr("骨骼层级"),
        callback=lambda: config.influences_display_mode.set(
            Config.InfluencesDisplayHierarchy
        ),
        tooltip=tr("按照 Maya 骨骼父子关系显示影响物"),
    )
    flat_action = actions.define_action(
        parent,
        tr("原版平铺"),
        callback=lambda: config.influences_display_mode.set(
            Config.InfluencesDisplayFlat
        ),
        tooltip=tr("按照 ngSkinTools2 原版方式平铺显示影响物"),
    )

    for display_action in (hierarchy_action, flat_action):
        display_action.setCheckable(True)
        group.addAction(display_action)

    @signal.on(config.influences_display_mode.changed, qtParent=parent)
    def update():
        hierarchy_action.setChecked(
            config.influences_display_mode()
            == Config.InfluencesDisplayHierarchy
        )
        flat_action.setChecked(
            config.influences_display_mode() == Config.InfluencesDisplayFlat
        )

    update()
    return group, hierarchy_action, flat_action


icon_mask = QtGui.QIcon(":/blendColors.svg")
icon_dq = QtGui.QIcon(":/rotate_M.png")
icon_joint = QtGui.QIcon(":/joint.svg")
icon_joint_disabled = qt.image_icon("joint_disabled.png")
icon_transform = QtGui.QIcon(":/cube.png")
icon_transform_disabled = qt.image_icon("cube_disabled.png")


def _nearest_parent_influence_path(path, influence_paths):
    """Return the nearest Maya DAG ancestor that is also a skin influence."""
    if not path or "|" not in path:
        return None

    parent_path = path.rsplit("|", 1)[0]
    while parent_path:
        if parent_path in influence_paths:
            return parent_path
        parent_path = parent_path.rsplit("|", 1)[0]
    return None


def _resolve_maya_long_dag_paths(paths):
    """Resolve all influence paths with one Maya command round-trip."""
    paths = list(paths)
    query_paths = list(set([path for path in paths if path]))
    if not query_paths:
        return [None for _path in paths]
    try:
        from maya import cmds

        matches = cmds.ls(query_paths, long=True) or []
    except Exception as err:
        log.warning("failed to resolve influence DAG paths: %s", err)
        matches = [path for path in paths if path and path.startswith("|")]
    return drop_duplicate_dag_paths(resolve_unique_dag_paths(paths, matches))


class FrozenLockColumn(QtWidgets.QWidget):
    """Paint the lock column above the horizontally scrolling tree viewport."""

    def __init__(self, view, items, buttons, width, parent=None):
        super(FrozenLockColumn, self).__init__(parent or view)
        self.view = view
        self.items = items
        self.buttons = buttons
        self.width = width
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
        self.setObjectName("ngSkinTools2FrozenLockColumn")
        self.raise_()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setClipRect(event.rect())
        palette = self.view.palette()
        painter.fillRect(event.rect(), palette.color(QtGui.QPalette.Base))

        for item in list(self.items.values()):
            if item.treeWidget() is not self.view:
                continue
            row = self.view.visualItemRect(item)
            if not row.isValid() or not row.intersects(event.rect()):
                continue

            row_rect = QtCore.QRect(0, row.top(), self.width, row.height())
            if item.isSelected():
                painter.fillRect(row_rect, palette.color(QtGui.QPalette.Highlight))

            button = self.buttons.get(item.data(0, QtCore.Qt.UserRole + 1))
            if button is None:
                continue

            icon = button.icon()
            if icon.isNull():
                continue

            icon_size = button.iconSize()
            icon_rect = QtCore.QRect(
                (self.width - icon_size.width()) // 2,
                row.top() + (row.height() - icon_size.height()) // 2,
                icon_size.width(),
                icon_size.height(),
            )
            mode = (
                QtGui.QIcon.Disabled
                if not button.isEnabled()
                else QtGui.QIcon.Normal
            )
            icon.paint(painter, icon_rect, QtCore.Qt.AlignCenter, mode)

        painter.setPen(palette.color(QtGui.QPalette.Mid))
        painter.drawLine(self.width - 1, 0, self.width - 1, self.height())


class FrozenLockColumnFilter(QtCore.QObject):
    """Forward clicks in the frozen lock column to the real row buttons."""

    def __init__(self, view, items, buttons, width):
        super(FrozenLockColumnFilter, self).__init__(view.viewport())
        self.view = view
        self.items = items
        self.buttons = buttons
        self.width = width
        self.overlay = None
        self.pressed = False

    def _item_at_y(self, y):
        for item in list(self.items.values()):
            if item.treeWidget() is not self.view:
                continue
            row = self.view.visualItemRect(item)
            if row.top() <= y < row.bottom():
                return item
        return None

    def eventFilter(self, watched, event):
        if watched is not self.view.viewport():
            return QtCore.QObject.eventFilter(self, watched, event)

        event_type = event.type()
        if event_type == QtCore.QEvent.Resize and self.overlay is not None:
            viewport_origin = self.view.viewport().mapTo(self.view, QtCore.QPoint(0, 0))
            self.overlay.setGeometry(
                viewport_origin.x(),
                viewport_origin.y(),
                self.width,
                self.view.viewport().height(),
            )
            self.overlay.raise_()
            return QtCore.QObject.eventFilter(self, watched, event)

        if event_type == QtCore.QEvent.MouseButtonPress:
            position = event.position().toPoint() if hasattr(event, "position") else event.pos()
            if position.x() < self.width and event.button() == QtCore.Qt.LeftButton:
                item = self._item_at_y(position.y())
                button = self.buttons.get(
                    item.data(0, QtCore.Qt.UserRole + 1)
                ) if item is not None else None
                if button is not None and button.isEnabled():
                    button.click()
                    self.pressed = True
                    return True

        if event_type == QtCore.QEvent.MouseButtonRelease and self.pressed:
            self.pressed = False
            return True

        return QtCore.QObject.eventFilter(self, watched, event)


def build_view(parent, actions, session, filter):
    """
    :param parent: ui parent
    :type actions: ngSkinTools2.ui.actions.Actions
    :type session: ngSkinTools2.ui.session.Session
    :type filter: InfluenceNameFilter
    """

    icon_locked = QtGui.QIcon(":/Lock_ON.png")
    icon_unlocked = QtGui.QIcon(":/Lock_OFF_grey.png")

    id_role = QtCore.Qt.UserRole + 1
    hierarchy_key_role = QtCore.Qt.UserRole + 2
    search_text_role = QtCore.Qt.UserRole + 3
    item_size_hint = QtCore.QSize(25 * scale_multiplier, 25 * scale_multiplier)

    def get_item_id(item):
        if item is None:
            return None
        return item.data(0, id_role)

    view = InfluenceTree(parent)
    view.setObjectName("ngSkinTools2InfluenceTree")

    tree_items = {}
    hierarchy_items = {}
    lock_buttons = {}
    name_column_content_width = {"value": int(40 * scale_multiplier)}

    def update_name_column_width():
        available_width = max(
            int(40 * scale_multiplier),
            view.viewport().width() - view.columnWidth(0),
        )
        target_width = max(
            available_width,
            name_column_content_width["value"],
        )
        if view.columnWidth(1) != target_width:
            view.setColumnWidth(1, target_width)

    view._name_column_resize_callback = update_name_column_width
    lock_column_width = int(28 * scale_multiplier)
    lock_overlay = FrozenLockColumn(
        view,
        tree_items,
        lock_buttons,
        lock_column_width,
    )
    lock_overlay_filter = FrozenLockColumnFilter(
        view,
        tree_items,
        lock_buttons,
        lock_column_width,
    )
    lock_overlay_filter.overlay = lock_overlay
    view.viewport().installEventFilter(lock_overlay_filter)
    lock_overlay.setGeometry(
        view.viewport().mapTo(view, QtCore.QPoint(0, 0)).x(),
        view.viewport().mapTo(view, QtCore.QPoint(0, 0)).y(),
        lock_column_width,
        view.viewport().height(),
    )
    lock_overlay.show()
    lock_overlay.raise_()
    view.verticalScrollBar().valueChanged.connect(
        lambda _value: lock_overlay.update()
    )
    view.horizontalScrollBar().valueChanged.connect(
        lambda _value: lock_overlay.update()
    )
    search_state = SearchTransition()
    dag_path_cache = {"key": None, "paths": None}
    hierarchy_expanded_keys = set()
    last_display_mode = {"value": config.influences_display_mode()}

    def update_lock_icons(item_ids, locked_ids):
        """Update lock buttons in place so toggling never rebuilds the tree."""
        locked_ids = set(locked_ids or [])
        for target_id in item_ids:
            tree_item = tree_items.get(target_id)
            if tree_item is None:
                continue
            button = lock_buttons.get(target_id)
            if button is None:
                continue
            is_locked = target_id in locked_ids
            target_name = tree_item.toolTip(1) or tree_item.text(1)
            operation = tr("解锁") if is_locked else tr("锁定")
            description = tr("{0}影响物：{1}").format(operation, target_name)
            button.setIcon(icon_locked if is_locked else icon_unlocked)
            button.setToolTip(description)
            button.setStatusTip(description)
        lock_overlay.update()

    def build_items(view, items, layer):
        # type: (QtWidgets.QTreeWidget, list[InfluenceInfo], Layer) -> None
        is_group_layer = layer is not None and layer.num_children != 0

        def rebuild_buttons(item, item_id, buttons):
            def lock_unlock_handler():
                def handler(_checked=False):
                    updated, targets = toggle_locked_influences(
                        layer.locked_influences,
                        item_id,
                        layer.paint_targets,
                    )
                    if list(layer.locked_influences or []) == updated:
                        return
                    layer.locked_influences = updated
                    log.info("updated locked influences to %r", updated)
                    update_lock_icons(targets, updated)

                return handler

            if "unlocked" in buttons or "locked" in buttons:
                button = QtWidgets.QToolButton(view)
                button.setAutoRaise(True)
                button.setFocusPolicy(QtCore.Qt.NoFocus)
                button.setIconSize(QtCore.QSize(16 * scale_multiplier, 16 * scale_multiplier))
                button.setFixedSize(int(28 * scale_multiplier), int(25 * scale_multiplier))
                button.clicked.connect(lock_unlock_handler())
                view.setItemWidget(item, 0, button)
                lock_buttons[item_id] = button

        selected_ids = []
        if session.state.currentLayer.layer:
            selected_ids = session.state.currentLayer.layer.paint_targets
        current_id = None if not selected_ids else selected_ids[0]

        with qt.signals_blocked(view):
            tree_items.clear()
            hierarchy_items.clear()
            lock_buttons.clear()
            tree_root = view.invisibleRootItem()

            expanded_keys = set(hierarchy_expanded_keys)
            had_items = tree_root.childCount() != 0

            def collect_expanded(parent_item):
                for child_index in range(parent_item.childCount()):
                    child = parent_item.child(child_index)
                    hierarchy_key = child.data(0, hierarchy_key_role)
                    if hierarchy_key and child.isExpanded():
                        expanded_keys.add(hierarchy_key)
                    collect_expanded(child)

            if last_display_mode["value"] == Config.InfluencesDisplayHierarchy:
                expanded_keys.clear()
                collect_expanded(tree_root)
                hierarchy_expanded_keys.clear()
                hierarchy_expanded_keys.update(expanded_keys)
            view.clear()

            visible_items = list(wanted_tree_items(
                items=items,
                include_dq_item=session.state.skin_cluster_dq_channel_used,
                is_group_layer=is_group_layer,
                layer=layer,
                config=config,
                filter=None,
            ))

            influences_by_id = {influence.logicalIndex: influence for influence in items}
            raw_paths = [
                None if influences_by_id.get(item_id) is None else influences_by_id[item_id].path
                for item_id, _display_name, _icon, _buttons in visible_items
            ]
            cache_key = tuple(raw_paths)
            if dag_path_cache["key"] != cache_key:
                dag_path_cache["key"] = cache_key
                dag_path_cache["paths"] = _resolve_maya_long_dag_paths(raw_paths)

            records = []
            for visible_item, dag_path in zip(visible_items, dag_path_cache["paths"]):
                item_id, display_name, icon, buttons = visible_item
                influence = influences_by_id.get(item_id)
                records.append(
                    {
                        "id": item_id,
                        "display_name": display_name,
                        "icon": icon,
                        "buttons": buttons,
                        "dag_path": dag_path,
                        "search_text": None if influence is None else influence.path_name(),
                    }
                )

            searching = bool(filter.currentFilterString)
            hierarchy_enabled = (
                config.influences_display_mode()
                == Config.InfluencesDisplayHierarchy
            )
            records = prepare_display_records(
                records,
                hierarchy_enabled=hierarchy_enabled,
                is_match=filter.is_match if searching else None,
            )

            records_by_path = {record["dag_path"]: record for record in records if record["dag_path"]}
            influence_paths = set(records_by_path.keys())
            created_records = {}

            def create_record(record):
                record_key = record["dag_path"] or "special:{0}".format(record["id"])
                if record_key in created_records:
                    return created_records[record_key]

                parent_item = tree_root
                label = record["display_name"]
                if record["dag_path"] and hierarchy_enabled:
                    parent_path = record.get("display_parent_path")
                    if not searching:
                        parent_path = _nearest_parent_influence_path(
                            record["dag_path"],
                            influence_paths,
                        )
                    if parent_path is not None:
                        parent_item = create_record(records_by_path[parent_path])
                    label = record["dag_path"].rsplit("|", 1)[-1]

                item = QtWidgets.QTreeWidgetItem(["", label])
                item.setData(0, hierarchy_key_role, record_key)
                item.setData(0, id_role, record["id"])
                item.setData(0, search_text_role, record["search_text"])
                item.setIcon(1, record["icon"])
                item.setSizeHint(0, item_size_hint)
                item.setSizeHint(1, item_size_hint)
                if record["dag_path"]:
                    item.setToolTip(1, record["dag_path"])
                parent_item.addChild(item)

                tree_items[record["id"]] = item
                if record["id"] == current_id:
                    view.setCurrentItem(item, 1, QtCore.QItemSelectionModel.NoUpdate)
                item.setSelected(record["id"] in selected_ids)
                rebuild_buttons(item, record["id"], record["buttons"])

                created_records[record_key] = item
                return item

            for record in records:
                create_record(record)

            hierarchy_items.update(created_records)
            def widest_item(parent_item, depth=0):
                widest = 0
                for child_index in range(parent_item.childCount()):
                    child = parent_item.child(child_index)
                    text_width = view.fontMetrics().width(child.text(1))
                    icon_width = view.iconSize().width()
                    if icon_width <= 0:
                        icon_width = 16 * scale_multiplier
                    widest = max(
                        widest,
                        depth * view.indentation() + text_width + icon_width + 40 * scale_multiplier,
                        widest_item(child, depth + 1),
                    )
                return widest

            name_column_content_width["value"] = max(
                int(widest_item(tree_root)),
                int(40 * scale_multiplier),
            )
            update_name_column_width()
            if hierarchy_enabled:
                apply_expansion_policy(
                    view,
                    created_records,
                    had_items,
                    filter.currentFilterString,
                    expanded_keys,
                )
            update_lock_icons(
                [record["id"] for record in records],
                layer.locked_influences if layer is not None else [],
            )
            last_display_mode["value"] = config.influences_display_mode()

    view.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
    view.setUniformRowHeights(True)
    view.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
    view.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
    actions.addInfluencesActions(view)
    from ngSkinTools2.ui import actions as actions_module

    view.addAction(actions.separator(parent, tr("锁定管理")))

    def set_all_skin_influences_locked(lock):
        layer = session.state.currentLayer.layer
        skin_cluster = session.state.currentLayer.selectedSkinCluster
        if (
            layer is None
            or skin_cluster is None
            or getattr(layer, "num_children", 0) != 0
        ):
            return

        influences = list_influences(skin_cluster)
        if not apply_skin_cluster_influence_lock(layer, influences, lock):
            return

        log.info(
            "%s all influences for skinCluster %r",
            "locked" if lock else "unlocked",
            skin_cluster,
        )
        update_lock_icons(
            [influence.logicalIndex for influence in influences],
            layer.locked_influences,
        )

    lock_all_action = actions_module.define_action(
        view,
        tr("锁定全部蒙皮影响物"),
        callback=lambda: set_all_skin_influences_locked(True),
        tooltip=tr("锁定当前 skinCluster 中的全部影响物"),
    )
    unlock_all_action = actions_module.define_action(
        view,
        tr("解锁全部蒙皮影响物"),
        callback=lambda: set_all_skin_influences_locked(False),
        tooltip=tr("解锁当前 skinCluster 中的全部影响物"),
    )
    view.addAction(lock_all_action)
    view.addAction(unlock_all_action)

    def set_inverse_skin_influences_locked(lock):
        layer = session.state.currentLayer.layer
        skin_cluster = session.state.currentLayer.selectedSkinCluster
        if (
            layer is None
            or skin_cluster is None
            or getattr(layer, "num_children", 0) != 0
        ):
            return

        selected_ids = [get_item_id(item) for item in view.selectedItems()]
        selected_ids = [influence_id for influence_id in selected_ids if influence_id is not None]
        influences = list_influences(skin_cluster)
        if not apply_inverse_skin_cluster_influence_lock(layer, influences, selected_ids, lock):
            return

        update_lock_icons(
            [influence.logicalIndex for influence in influences],
            layer.locked_influences,
        )

    lock_inverse_action = actions_module.define_action(
        view,
        tr("锁定反向选择"),
        callback=lambda: set_inverse_skin_influences_locked(True),
        tooltip=tr("锁定当前未选中的蒙皮影响物"),
    )
    unlock_inverse_action = actions_module.define_action(
        view,
        tr("解锁反向选择"),
        callback=lambda: set_inverse_skin_influences_locked(False),
        tooltip=tr("解锁当前未选中的蒙皮影响物"),
    )
    view.addAction(lock_inverse_action)
    view.addAction(unlock_inverse_action)

    def update_bulk_lock_actions_enabled():
        layer = session.state.currentLayer.layer
        enabled = (
            layer is not None
            and session.state.currentLayer.selectedSkinCluster is not None
            and getattr(layer, "num_children", 0) == 0
        )
        lock_all_action.setEnabled(enabled)
        unlock_all_action.setEnabled(enabled)
        lock_inverse_action.setEnabled(enabled)
        unlock_inverse_action.setEnabled(enabled)

    update_bulk_lock_actions_enabled()
    view.addAction(actions.separator(parent, tr("显示设置")))
    view.addAction(actions.show_used_influences_only)
    view.addAction(actions.set_influences_sorted)
    view.addAction(actions.separator(parent, tr("骨骼层级")))

    def expand_selected_branches():
        for item in descendant_items(view.selectedItems()):
            item.setExpanded(True)

    def collapse_selected_branches():
        for item in descendant_items(view.selectedItems()):
            item.setExpanded(False)

    def select_selected_hierarchies():
        items = descendant_items(view.selectedItems())
        if not items:
            return
        with qt.signals_blocked(view):
            view.clearSelection()
            for item in items:
                item.setSelected(True)

    expand_selected_action = actions_module.define_action(
        view, tr("展开当前选择"), callback=expand_selected_branches
    )
    collapse_selected_action = actions_module.define_action(
        view, tr("折叠当前选择"), callback=collapse_selected_branches
    )
    select_hierarchy_action = actions_module.define_action(
        view, tr("选择层级"), callback=select_selected_hierarchies
    )
    expand_all_action = actions_module.define_action(view, tr("展开全部"), callback=view.expandAll)
    collapse_all_action = actions_module.define_action(view, tr("折叠全部"), callback=view.collapseAll)
    view.addAction(expand_selected_action)
    view.addAction(collapse_selected_action)
    view.addAction(select_hierarchy_action)
    view.addAction(expand_all_action)
    view.addAction(collapse_all_action)

    @qt.on(view.customContextMenuRequested)
    def show_context_menu(position):
        target_item = view.itemAt(position)
        target_id = context_influence_id(get_item_id(target_item))
        if target_item is not None and target_item.isSelected():
            target_ids = [
                influence_id
                for influence_id in (
                    context_influence_id(get_item_id(item))
                    for item in view.selectedItems()
                )
                if influence_id is not None
            ]
        else:
            target_ids = [target_id] if target_id is not None else []
        menu = QtWidgets.QMenu(view)

        for existing_action in view.actions():
            if existing_action is actions.select_affected_vertices:
                targeted_action = actions_module.define_action(
                    menu,
                    existing_action.text(),
                    callback=lambda checked=False, influence_ids=target_ids: (
                        select_affected_vertices(session, influence_ids)
                    ),
                    tooltip=existing_action.toolTip(),
                )
                targeted_action.setEnabled(bool(target_ids) and existing_action.isEnabled())
                menu.addAction(targeted_action)
            else:
                menu.addAction(existing_action)

        menu.exec_(view.viewport().mapToGlobal(position))

    hierarchy_actions_enabled = (
        config.influences_display_mode()
        == Config.InfluencesDisplayHierarchy
    )
    expand_all_action.setEnabled(hierarchy_actions_enabled)
    collapse_all_action.setEnabled(hierarchy_actions_enabled)
    expand_selected_action.setEnabled(hierarchy_actions_enabled)
    collapse_selected_action.setEnabled(hierarchy_actions_enabled)
    select_hierarchy_action.setEnabled(hierarchy_actions_enabled)
    view.setIndentation(10 * scale_multiplier)
    view.header().setStretchLastSection(False)
    view.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
    view.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollPerPixel)
    view.setHeaderLabels(["", tr("影响物")])
    view.setTreePosition(1)
    view.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Fixed)
    view.header().setSectionResizeMode(1, QtWidgets.QHeaderView.Interactive)
    view.setColumnWidth(0, int(28 * scale_multiplier))

    # The native header text scrolls with the section contents.  Paint a small
    # transparent-to-mouse overlay over the influence section so its title stays
    # anchored to the left edge while the body is horizontally scrolled.
    frozen_header = FrozenInfluenceHeader(view)

    def update_frozen_header_geometry():
        header = view.header()
        header_origin = header.mapTo(view, QtCore.QPoint(0, 0))
        lock_width = view.columnWidth(0)
        frozen_header.setGeometry(
            header_origin.x() + lock_width,
            header_origin.y(),
            max(0, header.width() - lock_width),
            header.height(),
        )
        frozen_header.raise_()
        frozen_header.update()

    view._frozen_header_resize_callback = update_frozen_header_geometry
    update_frozen_header_geometry()
    frozen_header.show()
    frozen_header.raise_()
    view.recursive_branch_toggle_filter = RecursiveBranchToggleFilter(view)
    view.viewport().installEventFilter(view.recursive_branch_toggle_filter)

    # view.setHeaderHidden(True)
    def refresh_items():
        items = list_influences(session.state.currentLayer.selectedSkinCluster)

        def sort_func(a):
            """
            :type a: InfluenceInfo
            """
            return a.name

        # items = sorted(items, key=sort_func)
        build_items(view, items, session.state.currentLayer.layer)

    @signal.on(
        config.influences_show_used_influences_only.changed,
        config.influences_sort.changed,
        config.influences_display_mode.changed,
        session.events.influencesListUpdated,
    )
    def influence_list_changed():
        update_bulk_lock_actions_enabled()
        hierarchy_actions_enabled = (
            config.influences_display_mode()
            == Config.InfluencesDisplayHierarchy
        )
        expand_all_action.setEnabled(hierarchy_actions_enabled)
        collapse_all_action.setEnabled(hierarchy_actions_enabled)
        expand_selected_action.setEnabled(hierarchy_actions_enabled)
        collapse_selected_action.setEnabled(hierarchy_actions_enabled)
        select_hierarchy_action.setEnabled(hierarchy_actions_enabled)
        refresh_items()

    @signal.on(filter.changed)
    def filter_changed():
        layer = session.state.currentLayer.layer
        skin_cluster = session.state.currentLayer.selectedSkinCluster
        layer_id = None if layer is None else layer.id

        if filter.currentFilterString and search_state.snapshot is None and layer is not None:
            search_state.enter(
                filter.currentFilterString,
                capture_tree_snapshot(
                    view,
                    hierarchy_items,
                    get_item_id,
                    skin_cluster,
                    layer_id,
                    layer.paint_targets,
                ),
            )

        snapshot = search_state.leave(filter.currentFilterString)
        refresh_items()

        if snapshot is None or layer is None or not snapshot.matches(skin_cluster, layer_id):
            return

        with qt.signals_blocked(view):
            restored_targets = restore_tree_snapshot(
                view,
                hierarchy_items,
                tree_items,
                snapshot,
            )
        if list(layer.paint_targets) != restored_targets:
            layer.paint_targets = restored_targets

        def restore_scroll_position():
            view.verticalScrollBar().setValue(snapshot.scroll_value)

        QtCore.QTimer.singleShot(0, restore_scroll_position)

    @signal.on(session.events.currentLayerChanged, qtParent=view)
    def current_layer_changed():
        update_bulk_lock_actions_enabled()
        snapshot = search_state.snapshot
        skin_cluster = session.state.currentLayer.selectedSkinCluster
        layer = session.state.currentLayer.layer
        layer_id = None if layer is None else layer.id
        if snapshot is not None and not snapshot.matches(skin_cluster, layer_id):
            search_state.clear()

        if not session.state.currentLayer.layer:
            build_items(view, [], None)
        else:
            log.info("current layer changed to %s", session.state.currentLayer.layer)
            refresh_items()
            current_influence_changed()

    @signal.on(session.events.currentInfluenceChanged, qtParent=view)
    def current_influence_changed():
        if session.state.currentLayer.layer is None:
            return

        log.info("current influence changed - updating item selection")
        with qt.signals_blocked(view):
            targets = session.state.currentLayer.layer.paint_targets
            should_reveal = sample_influence_reveal_state.should_reveal()
            for tree_item in tree_items.values():
                selected = get_item_id(tree_item) in targets
                tree_item.setSelected(selected)

            target_item = first_existing_target(tree_items, targets)
            if target_item is not None:
                if view.currentItem() is not target_item:
                    view.setCurrentItem(
                        target_item,
                        0,
                        QtCore.QItemSelectionModel.NoUpdate,
                    )
                if should_reveal:
                    def reveal_after_refresh():
                        if target_item.treeWidget() is view:
                            reveal_item(
                                view,
                                target_item,
                                QtWidgets.QAbstractItemView.PositionAtCenter,
                                set_current=False,
                            )

                    QtCore.QTimer.singleShot(0, reveal_after_refresh)

    @qt.on(view.currentItemChanged)
    def current_item_changed(curr, prev):
        if curr is None:
            return

        if session.state.selectedSkinCluster is None:
            return

        if not session.state.currentLayer.layer:
            return

        log.info("focused item changed: %r", get_item_id(curr))
        sync_paint_targets_to_selection()

    @qt.on(view.itemSelectionChanged)
    def sync_paint_targets_to_selection():
        log.info("syncing paint targets")
        selected_ids = [get_item_id(item) for item in view.selectedItems()]
        selected_ids = [i for i in selected_ids if i is not None]

        current_item = view.currentItem()
        if current_item and current_item.isSelected():
            # move id of current item to front, if it's selected
            item_id = get_item_id(current_item)
            selected_ids.remove(item_id)
            selected_ids = [item_id] + selected_ids

        if session.state.currentLayer.layer:
            session.state.currentLayer.layer.paint_targets = selected_ids

    current_layer_changed()

    return view


def get_icon(influence, is_joint):
    if influence.used:
        return icon_joint if is_joint else icon_transform
    return icon_joint_disabled if is_joint else icon_transform_disabled


def wanted_tree_items(
    layer,
    config,
    is_group_layer,
    include_dq_item,
    filter,
    items,
):
    """

    :type items: list[InfluenceInfo]
    """

    if layer is None:
        return

    # calculate "used" regardless as we're displaying it visually even if "show used influences only" is toggled off
    used = set((layer.get_used_influences() or []))
    locked = set((layer.locked_influences or []))
    for i in items:
        i.used = i.logicalIndex in used
        i.locked = i.logicalIndex in locked

    if config.influences_show_used_influences_only() and layer is not None:
        items = [i for i in items if i.used]

    if is_group_layer:
        items = []

    yield "mask", "[Mask]", icon_mask, []
    if not is_group_layer and include_dq_item:
        yield "dq", "[DQ Weights]", icon_dq, []

    names = influence_names.unique_names([i.path_name() for i in items])
    for i, name in zip(items, names):
        i.unique_name = name

    if config.influences_sort() == Config.InfluencesSortDescending:
        items = list(sorted(items, key=lambda i: i.unique_name))

    for i in items:
        is_joint = i.path is not None
        if filter is None or filter.is_match(i.path_name()):
            yield i.logicalIndex, i.unique_name, get_icon(i, is_joint), ["locked" if i.locked else "unlocked"]
