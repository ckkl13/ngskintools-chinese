from ngSkinTools2 import signal
from ngSkinTools2.api import PaintTool
from ngSkinTools2.api.paint import popups
from ngSkinTools2.api.pyside import QtCore, QtGui, QtWidgets
from ngSkinTools2.ui import intensity_presets, qt, widgets
from ngSkinTools2.ui.layout import scale_multiplier
from ngSkinTools2.ui.options import config


def brush_settings_popup(paint):
    """

    :type paint: PaintTool
    """
    window = QtWidgets.QWidget(qt.mainWindow)
    window.setWindowFlags(QtCore.Qt.Popup | QtCore.Qt.FramelessWindowHint)
    window.setAttribute(QtCore.Qt.WA_DeleteOnClose)

    spacing = 5

    layout = QtWidgets.QVBoxLayout()
    layout.setSpacing(spacing)

    intensity_slider = widgets.NumberSliderGroup(decimals=5)
    intensity_slider.spinner.setDecimals(config.paint_intensity_decimals())
    @signal.on(config.paint_intensity_decimals.changed, qtParent=window)
    def intensity_decimals_changed():
        intensity_slider.spinner.setDecimals(config.paint_intensity_decimals())
    widgets.set_paint_expo(intensity_slider, paint.paint_mode)
    intensity_slider.set_value(paint.intensity)

    @qt.on(intensity_slider.slider.sliderReleased, intensity_slider.spinner.editingFinished)
    def close_with_slider_intensity():
        close_with_intensity(intensity_slider.value())

    def close_with_intensity(value):
        paint.intensity = value
        window.close()

    layout.addLayout(intensity_slider.layout())
    layout.addWidget(
        intensity_presets.create(
            window,
            value_getter=lambda: paint.intensity,
            value_setter=lambda value: setattr(paint, "intensity", value),
            on_applied=window.close,
        )
    )

    group = QtWidgets.QGroupBox("Brush Intensity")
    group.setLayout(layout)

    layout = QtWidgets.QVBoxLayout()
    layout.setContentsMargins(4 * scale_multiplier, 4 * scale_multiplier, 4 * scale_multiplier, 4 * scale_multiplier)
    layout.addWidget(group)

    window.setLayout(layout)

    window.show()
    mp = QtGui.QCursor.pos()
    window.move(mp.x() - window.size().width() / 2, mp.y() - window.size().height() / 2)

    window.activateWindow()

    popups.close_all()
    popups.add(window)
