# -*- coding: utf-8 -*-
"""Batch import ngSkinTools2 JSON files whose names match mesh names."""

from ngSkinTools2.ui import i18n
from ngSkinTools2.ui.i18n import tr
import io
import os
import json
from functools import wraps

from maya import cmds
from ngSkinTools2 import api as ngst_api
from ngSkinTools2.api import init_layers

# 默认权重文件夹：需要时只修改这一行
DEFAULT_FOLDER = r"D:/"
SKELETON_FILE = "ng_skin_bindings.json"

try:
    from PySide6 import QtWidgets, QtCore
    from shiboken6 import wrapInstance, isValid
except ImportError:
    from PySide2 import QtWidgets, QtCore
    from shiboken2 import wrapInstance, isValid


def _maya_window():
    import maya.OpenMayaUI as omui
    return wrapInstance(int(omui.MQtUtil.mainWindow()), QtWidgets.QWidget)


def _mesh_for_file(json_path):
    """
Return the Maya node named like the JSON file, or None."""
    name = os.path.splitext(os.path.basename(json_path))[0]
    return name if cmds.objExists(name) else None


def _selected_mesh_transforms():
    """Return selected mesh transforms, including when a mesh shape is selected."""
    result = []
    for node in cmds.ls(selection=True, long=True, objectsOnly=True) or []:
        if cmds.nodeType(node) == "mesh":
            parents = cmds.listRelatives(node, parent=True, fullPath=True) or []
            node = parents[0] if parents else node
        if cmds.nodeType(node) != "transform":
            continue
        shapes = cmds.listRelatives(node, shapes=True, noIntermediate=True,
                                    fullPath=True) or []
        if any(cmds.nodeType(shape) == "mesh" for shape in shapes) and node not in result:
            result.append(node)
    return result


def _skin_cluster(obj):
    shapes = cmds.listRelatives(obj, shapes=True, noIntermediate=True,
                                fullPath=True) or []
    for shape in shapes:
        skins = cmds.ls(cmds.listHistory(shape) or [], type="skinCluster") or []
        if skins:
            return skins[0]
    return None


def _rename_imported_layers(target, existing_layer_ids):
    """Rename layers created by this import without touching existing layers."""
    layers = init_layers(target)
    all_layers = layers.list()
    used_names = {layer.name for layer in all_layers
                  if layer.id in existing_layer_ids}
    for layer in all_layers:
        if layer.id in existing_layer_ids:
            continue
        base_name = tr(u"导入权重")
        name = base_name
        suffix = 1
        while name in used_names:
            name = u"{} ({})".format(base_name, suffix)
            suffix += 1
        layer.name = name
        used_names.add(name)


def _binding_file(folder):
    return os.path.join(folder, SKELETON_FILE)


def _load_bindings(folder):
    path = _binding_file(folder)
    if not os.path.isfile(path):
        return {}
    with io.open(path, "r", encoding="utf-8") as stream:
        return json.load(stream)


def _undo_chunk(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        cmds.undoInfo(openChunk=True, chunkName="ngBatchImport")
        try:
            return function(*args, **kwargs)
        finally:
            cmds.undoInfo(closeChunk=True)
    return wrapped


class NgBatchImportDialog(QtWidgets.QDialog):
    UI_VERSION = 13
    _instance = None

    def __init__(self, parent=None):
        super(NgBatchImportDialog, self).__init__(parent)
        self.setWindowTitle(tr(u"批量导入导出"))
        self.setObjectName("ngBatchImportDialog")
        self.setProperty("ngBatchImportDialogVersion", self.UI_VERSION)
        self.setProperty("ngBatchImportDialogI18nModule", id(i18n))
        self.setWindowFlags(
            QtCore.Qt.Window |
            QtCore.Qt.WindowMinimizeButtonHint |
            QtCore.Qt.WindowMaximizeButtonHint |
            QtCore.Qt.WindowCloseButtonHint
        )

        self.mode = QtWidgets.QComboBox()
        self.mode.addItem(
            tr(u"顶点ID", u"Vertex ID"), ngst_api.VertexTransferMode.vertexId
        )
        self.mode.addItem(tr(u"表面上最近的点"), ngst_api.VertexTransferMode.closestPoint)
        self.mode.addItem(tr(u"UV空间"), ngst_api.VertexTransferMode.uvSpace)
        self.mode.setToolTip(tr(u"选择顶点匹配方式"))
        self.mode.setStatusTip(tr(u"选择顶点匹配方式"))
        self.mode.currentIndexChanged.connect(self._update_vertex_mode_tooltip)

        self.import_type = QtWidgets.QComboBox()
        self.import_type.addItem(tr(u"名称", u"Name"), "by_name")
        self.import_type.addItem(tr(u"1对多"), "one_to_many")
        self.import_type.setToolTip(tr(u"按名称导入匹配文件，或将一个文件导入到多个所选模型"))
        self.import_type.setStatusTip(tr(u"选择批量导入方式"))

        self.post_import_action = QtWidgets.QComboBox()
        self.post_import_action.addItem(tr(u"不处理"), "none")
        self.post_import_action.addItem(tr(u"合并图层"), "merge")
        self.post_import_action.addItem(tr(u"删除 ng 节点"), "delete")
        self.post_import_action.setToolTip(tr(u"在本次全部导入完成后，对成功导入的模型执行所选操作"))
        self.post_import_action.setStatusTip(tr(u"选择导入完成后的处理方式"))

        self.folder = QtWidgets.QLineEdit()
        self.folder.setText(DEFAULT_FOLDER)
        self.folder.setReadOnly(True)
        self.folder.setMinimumWidth(150)
        self.folder.setMaximumWidth(220)
        self.browse_button = QtWidgets.QPushButton(tr(u"选择文件夹"))
        self.browse_button.setMaximumWidth(90)
        self.browse_button.setToolTip(tr(u"选择包含 ngSkinTools JSON 文件的文件夹"))
        self.browse_button.setStatusTip(tr(u"选择包含 ngSkinTools JSON 文件的文件夹"))
        self.browse_button.clicked.connect(self.choose_folder)

        self.run_button = QtWidgets.QPushButton(tr(u"开始导入"))
        self.run_button.setToolTip(tr(u"按所选导入方式批量导入权重"))
        self.run_button.setStatusTip(tr(u"按所选导入方式批量导入权重"))
        self.run_button.clicked.connect(self.import_all)

        self.export_button = QtWidgets.QPushButton(tr(u"导出所选"))
        self.export_button.setToolTip(tr(u"将所选模型的 ngSkinTools 权重导出到默认文件夹"))
        self.export_button.setStatusTip(tr(u"将所选模型的 ngSkinTools 权重导出到默认文件夹"))
        self.export_button.clicked.connect(self.export_selected)

        try:
            combo_size_policy = QtWidgets.QComboBox.AdjustToMinimumContentsLengthWithIcon
        except AttributeError:
            combo_size_policy = QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
        for combo, minimum_chars in (
            (self.mode, 16),
            (self.import_type, 8),
            (self.post_import_action, 12),
        ):
            combo.setSizeAdjustPolicy(combo_size_policy)
            combo.setMinimumContentsLength(minimum_chars)
        self.mode.setMaximumWidth(210)
        self.import_type.setMaximumWidth(150)
        self.post_import_action.setMaximumWidth(170)

        form = QtWidgets.QFormLayout()
        try:
            form.setFieldGrowthPolicy(QtWidgets.QFormLayout.FieldsStayAtSizeHint)
        except AttributeError:
            form.setFieldGrowthPolicy(
                QtWidgets.QFormLayout.FieldGrowthPolicy.FieldsStayAtSizeHint
            )
        form.setContentsMargins(4, 4, 4, 4)
        form.setHorizontalSpacing(3)
        form.setVerticalSpacing(2)
        row = QtWidgets.QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(3)
        row.addWidget(self.folder)
        row.addWidget(self.browse_button)
        self._form_label_keys = (u"权重文件夹", u"导入方式", u"导入后处理", u"顶点匹配")
        self._form_labels = [QtWidgets.QLabel(tr(label), self) for label in self._form_label_keys]
        form.addRow(self._form_labels[0], row)
        form.addRow(self._form_labels[1], self.import_type)
        form.addRow(self._form_labels[2], self.post_import_action)
        form.addRow(self._form_labels[3], self.mode)
        buttons = QtWidgets.QHBoxLayout()
        buttons.setContentsMargins(0, 0, 0, 0)
        buttons.setSpacing(4)
        buttons.addWidget(self.run_button)
        buttons.addWidget(self.export_button)
        form.addRow(buttons)
        self.setLayout(form)
        self.form = form
        self._language_listener = self.retranslate_ui
        i18n.register_language_listener(self._language_listener)
        self.retranslate_ui()

    def retranslate_ui(self, *_):
        self.setWindowTitle(tr(u"批量导入导出"))
        for combo, labels in (
            (
                self.mode,
                ((u"顶点ID", u"Vertex ID"), (u"表面上最近的点", None), (u"UV空间", None)),
            ),
            (self.import_type, ((u"名称", u"Name"), (u"1对多", None))),
            (
                self.post_import_action,
                ((u"不处理", None), (u"合并图层", None), (u"删除 ng 节点", None)),
            ),
        ):
            for index, (label, english) in enumerate(labels):
                combo.setItemText(index, tr(label, english))

        for widget, source in (
            (self.mode, u"选择顶点匹配方式"),
            (self.import_type, u"按名称导入匹配文件，或将一个文件导入到多个所选模型"),
            (self.post_import_action, u"在本次全部导入完成后，对成功导入的模型执行所选操作"),
            (self.browse_button, u"选择包含 ngSkinTools JSON 文件的文件夹"),
            (self.run_button, u"按所选导入方式批量导入权重"),
            (self.export_button, u"将所选模型的 ngSkinTools 权重导出到默认文件夹"),
        ):
            widget.setToolTip(tr(source))
            widget.setStatusTip(tr(source))

        self._update_vertex_mode_tooltip()

        self.browse_button.setText(tr(u"选择文件夹"))
        self.run_button.setText(tr(u"开始导入"))
        self.export_button.setText(tr(u"导出所选"))
        for label, source in zip(self._form_labels, self._form_label_keys):
            label.setText(tr(source))

    def _update_vertex_mode_tooltip(self, *_):
        if self.mode.currentData() == ngst_api.VertexTransferMode.vertexId:
            source = u"按顶点ID(源和目标顶点数必须匹配)"
        else:
            source = u"选择顶点匹配方式"
        tooltip = tr(source)
        self.mode.setToolTip(tooltip)
        self.mode.setStatusTip(tooltip)

    def choose_folder(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, tr(u"选择 ng 权重文件夹"))
        if path:
            self.folder.setText(path)

    @_undo_chunk
    def import_all(self):
        one_to_many = self.import_type.currentData() == "one_to_many"
        if one_to_many:
            targets = _selected_mesh_transforms()
            if not targets:
                QtWidgets.QMessageBox.information(self, tr(u"提示"), tr(u"请先选择要接收权重的模型。"))
                return
            path, _ = QtWidgets.QFileDialog.getOpenFileName(
                self, tr(u"选择要导入的 ng 权重文件"), self.folder.text().strip(),
                u"ngSkinTools JSON (*.json)")
            if not path:
                return
            if os.path.basename(path).lower() == SKELETON_FILE.lower():
                QtWidgets.QMessageBox.warning(self, tr(u"提示"), tr(u"请选择权重 JSON 文件，不能选择骨骼绑定记录。"))
                return
            jobs = [(path, target) for target in targets]
            bindings = _load_bindings(os.path.dirname(path))
        else:
            folder = self.folder.text().strip()
            if not folder or not os.path.isdir(folder):
                QtWidgets.QMessageBox.warning(self, tr(u"提示"), tr(u"请先选择有效文件夹。"))
                return
            files = sorted(
                os.path.join(folder, f) for f in os.listdir(folder)
                if f.lower().endswith(".json") and
                f.lower() != SKELETON_FILE.lower())
            selected = {name.split("|")[-1] for name in
                        (cmds.ls(selection=True, long=True) or [])}
            if selected:
                files = [path for path in files
                         if os.path.splitext(os.path.basename(path))[0] in selected]
            if not files:
                message = tr(u"没有找到可导入的 .json 文件。")
                if selected:
                    message = tr(u"当前选择的模型没有对应的 .json 文件。")
                QtWidgets.QMessageBox.information(self, tr(u"提示"), message)
                return
            jobs = [(path, _mesh_for_file(path)) for path in files]
            bindings = _load_bindings(folder)

        imported, skipped, errors = [], [], []
        imported_targets = []
        config = ngst_api.InfluenceMappingConfig.transfer_defaults()
        for path, target in jobs:
            if not target:
                skipped.append(os.path.basename(path) + tr(u"（找不到同名网格）"))
                continue
            try:
                skin_cluster = _skin_cluster(target)
                if not skin_cluster:
                    joints = bindings.get(target.split("|")[-1], [])
                    if not joints and one_to_many:
                        source_name = os.path.splitext(os.path.basename(path))[0]
                        joints = bindings.get(source_name, [])
                    joints = [j for j in joints if cmds.objExists(j)]
                    if not joints:
                        raise RuntimeError(tr(u"目标没有蒙皮，且绑定记录中没有可用骨骼"))
                    cmds.skinCluster(joints, target, tsb=True)
                    print(tr(u"已先绑定蒙皮: {} -> {} 根骨骼").format(target, len(joints)))
                # Attach ngSkinTools data before transfer. Existing stacks stay intact;
                # create the initial base layer only for a pre-skinned target with none.
                layers = init_layers(target)
                if skin_cluster and not layers.list():
                    layers.add(tr(u"基础权重"))
                existing_layer_ids = {layer.id for layer in layers.list()}
                ngst_api.import_json(
                    target, path,
                    vertex_transfer_mode=self.mode.currentData(),
                    influences_mapping_config=config,
                )
                _rename_imported_layers(target, existing_layer_ids)
                imported.append(
                    u"{} -> {}".format(os.path.basename(path), target)
                    if one_to_many else os.path.basename(path))
                imported_targets.append(target)
                print(tr(u"已导入: {} -> {}").format(os.path.basename(path), target))
            except Exception as exc:
                errors.append(u"{} -> {}：{}".format(
                    os.path.basename(path), target, str(exc)))

        post_action = self.post_import_action.currentData()
        if post_action == "merge":
            for target in imported_targets:
                try:
                    target_layers = init_layers(target).list()
                    if len(target_layers) > 1:
                        ngst_api.merge_layers(target_layers)
                    print(tr(u"已合并图层: {}").format(target))
                except Exception as exc:
                    errors.append(tr(u"{}（合并图层失败）：{}").format(target, str(exc)))
        elif post_action == "delete":
            from ngSkinTools2.operations import removeLayerData
            for target in imported_targets:
                try:
                    removeLayerData.remove_custom_nodes(
                        interactive=False, meshes=[target])
                    print(tr(u"已删除 ng 节点: {}").format(target))
                except Exception as exc:
                    errors.append(tr(u"{}（删除 ng 节点失败）：{}").format(target, str(exc)))

        report = tr(u"导入成功：{} 个\n跳过：{} 个\n失败：{} 个").format(
            len(imported), len(skipped), len(errors))
        details = skipped + errors
        if details:
            report += u"\n\n" + u"\n".join(details)
        print(report)
        cmds.inViewMessage(
            amg=tr(u"<hl>导入完成：成功 {} 个，跳过 {} 个，失败 {} 个</hl>").format(
                len(imported), len(skipped), len(errors)),
            pos="midCenter", fade=True)

    @_undo_chunk
    def export_selected(self):
        folder = self.folder.text().strip() or DEFAULT_FOLDER
        if not os.path.isdir(folder):
            QtWidgets.QMessageBox.warning(self, tr(u"提示"), tr(u"导出文件夹不存在：\n") + folder)
            return

        selection = cmds.ls(selection=True, long=False) or []
        if not selection:
            cmds.warning(tr(u"请先选择需要导出的模型。"))
            return

        exported, errors = [], []
        bindings = _load_bindings(folder)
        for obj in selection:
            obj = obj.split("|")[-1]
            layer_base = None
            try:
                skin = _skin_cluster(obj)
                if not skin:
                    raise RuntimeError(tr(u"未找到蒙皮，无法记录骨骼"))
                bindings[obj] = cmds.skinCluster(skin, q=True, inf=True) or []
                layers = init_layers(obj)
                layer_base = layers.add(tr(u"基础权重"))
                output = os.path.join(folder, obj + ".json")
                ngst_api.export_json(obj, file=output)
                exported.append(output)
                print(tr(u"已导出: {} -> {}").format(obj, output))
            except Exception as exc:
                errors.append(obj + u"：" + str(exc))
            finally:
                if layer_base is not None:
                    try:
                        layers.delete(layer_base)
                    except Exception:
                        pass

        binding_data = json.dumps(bindings, ensure_ascii=False, indent=2)
        if not isinstance(binding_data, bytes):
            binding_data = binding_data.encode("utf-8")
        with io.open(_binding_file(folder), "wb") as stream:
            stream.write(binding_data)
        print(tr(u"骨骼绑定记录已保存: {}").format(_binding_file(folder)))

        report = tr(u"导出成功：{} 个\n失败：{} 个").format(len(exported), len(errors))
        if errors:
            report += u"\n\n" + u"\n".join(errors)
        print(report)
        cmds.inViewMessage(
            amg=tr(u"<hl>导出完成：成功 {} 个，失败 {} 个</hl>").format(
                len(exported), len(errors)),
            pos="midCenter", fade=True)

    def closeEvent(self, event):
        i18n.unregister_language_listener(self._language_listener)
        if NgBatchImportDialog._instance is self:
            NgBatchImportDialog._instance = None
        event.accept()


def show(force_rebuild=False):
    app = QtWidgets.QApplication.instance()
    folder_text = None
    vertex_mode = None
    import_type = None
    post_import_action = None
    for widget in app.allWidgets() if app else []:
        if widget.objectName() == "ngBatchImportDialog" and isValid(widget):
            if (
                not force_rebuild
                and widget.property("ngBatchImportDialogVersion") == NgBatchImportDialog.UI_VERSION
                and widget.property("ngBatchImportDialogI18nModule") == id(i18n)
            ):
                widget.show()
                widget.raise_()
                widget.activateWindow()
                NgBatchImportDialog._instance = widget
                return widget

            old_folder = widget.findChild(QtWidgets.QLineEdit)
            old_mode = getattr(widget, "mode", None)
            if old_mode is None:
                old_mode = widget.findChild(QtWidgets.QComboBox)
            old_import_type = getattr(widget, "import_type", None)
            old_post_import_action = getattr(widget, "post_import_action", None)
            if old_folder:
                folder_text = old_folder.text()
            if old_mode:
                vertex_mode = old_mode.currentData()
            if old_import_type:
                import_type = old_import_type.currentData()
            if old_post_import_action:
                post_import_action = old_post_import_action.currentData()
            widget.close()
            widget.deleteLater()

    NgBatchImportDialog._instance = NgBatchImportDialog(_maya_window())
    if folder_text is not None:
        NgBatchImportDialog._instance.folder.setText(folder_text)
    if vertex_mode is not None:
        index = NgBatchImportDialog._instance.mode.findData(vertex_mode)
        if index >= 0:
            NgBatchImportDialog._instance.mode.setCurrentIndex(index)
    if import_type is not None:
        index = NgBatchImportDialog._instance.import_type.findData(import_type)
        if index >= 0:
            NgBatchImportDialog._instance.import_type.setCurrentIndex(index)
    if post_import_action is not None:
        index = NgBatchImportDialog._instance.post_import_action.findData(post_import_action)
        if index >= 0:
            NgBatchImportDialog._instance.post_import_action.setCurrentIndex(index)
    NgBatchImportDialog._instance.show()
    screen = NgBatchImportDialog._instance.screen()
    if screen:
        available = screen.availableGeometry()
        size = NgBatchImportDialog._instance.sizeHint()
        NgBatchImportDialog._instance.resize(
            min(size.width(), available.width()),
            min(size.height(), available.height()))
        NgBatchImportDialog._instance.move(available.center() -
                                           NgBatchImportDialog._instance.rect().center())
    NgBatchImportDialog._instance.raise_()
    NgBatchImportDialog._instance.activateWindow()
    return NgBatchImportDialog._instance


if __name__ == "__main__":
    show()
