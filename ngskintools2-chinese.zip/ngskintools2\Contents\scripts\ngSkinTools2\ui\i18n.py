# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import codecs
import json
import os


LANGUAGES = ("zh_CN", "en_US")
_TRANSLATIONS_PATH = os.path.join(os.path.dirname(__file__), "translations_en_US.json")
with codecs.open(_TRANSLATIONS_PATH, "r", "utf-8-sig") as translation_file:
    _ENGLISH = json.load(translation_file)

# Keep Maya and ngSkinTools terminology consistent where a general translator
# would choose a different meaning for terms such as influence and skin layer.
_ENGLISH.update({
    "(自己)": "(Self)",
    "(不匹配)": "(not matched)",
    "(不在皮肤簇中)": "(not in skin cluster)",
    "（找不到同名网格）": " (mesh with the same name not found)",
    "{0}影响物：{1}": "{0} influence: {1}",
    "<hl>导出完成：成功 {} 个，失败 {} 个</hl>": "<hl>Export complete: {} successful, {} failed</hl>",
    "<hl>导入完成：成功 {} 个，跳过 {} 个，失败 {} 个</hl>": "<hl>Import complete: {} successful, {} skipped, {} failed</hl>",
    "按顶点ID(源和目标顶点数必须匹配)": "By vertex ID (source and destination vert count must match)",
    "按名称对影响进行排序": "Sort influences by name",
    "按照 Maya 骨骼父子关系显示影响物": "Show influences in the Maya joint hierarchy",
    "按照 ngSkinTools2 原版方式平铺显示影响物": "Show influences in the original ngSkinTools2 layout",
    "单组模式": "Single group mode",
    "导入/导出": "Import/Export",
    "导出为Json": "Export to Json",
    "从Json导入": "Import from Json",
    "从Json中导入图层…": "Import Layers from JSON…",
    "将图层导出为Json…": "Export Layers to Json...",
    "传递图层...": "Transfer layers...",
    "常用设置": "Common Settings",
    "图层操作": "Layer actions",
    "图层属性": "Layer properties",
    "蒙皮属性": "Skin Properties",
    "笔刷行为": "Brush behavior",
    "笔刷模式:": "Brush mode:",
    "笔刷形状:": "Brush shape:",
    "笔刷投影:": "Brush projection:",
    "笔刷迭代次数:": "Brush iterations:",
    "手绘板压力:": "Stylus pressure:",
    "强度精度：{0} 位": "Strength precision: {0} decimal places",
    "强度小数位数": "Strength Decimal Places",
    "集群:": "Clustering:",
    "镜像方向": "mirror_direction",
    "镜像方向:": "Mirror direction:",
    "镜像轴:": "Axis:",
    "镜像选项": "Mirroring options",
    "镜像要素:": "Elements to mirror:",
    "位置容差:": "Position tolerance:",
    "属性名称:": "Attribute name:",
    "命名方案:": "Naming scheme:",
    "接缝宽度:": "Seam width:",
    "目标图层:": "Destination layers:",
    "画笔模式:%s, 画笔形状: %s": "brush mode:%s, brush shape: %s",
    "绘制": "Paint",
    "设置权重": "Set Weights",
    "镜像": "Mirror",
    "样式": "Effects",
    "来源": "Source",
    "目标": "Target",
    "标签": "label",
    "规则": "Rules",
    "回到自己": "fallback to self",
    "距离": "distance",
    "软边圆": "Soft Brush",
    "硬边圆": "Hard Brush",
    "双四元权重": "Dual quaternion weights",
    "双四元数权重": "Dual Quaternion Weights",
    "这将会删除选中项的Ng节点.权重会保留，Ng图层会消失 确认删除么？": "This will remove ngSkinTools nodes from the selection. Weights will remain, but the ngSkinTools layers will be removed. Continue?",
    "导出文件夹不存在：\n": "The export folder does not exist:\n",
    "导入成功：{} 个\n跳过：{} 个\n失败：{} 个": "Imported: {}\nSkipped: {}\nFailed: {}",
    "导出成功：{} 个\n失败：{} 个": "Exported: {}\nFailed: {}",
    "点击后在视口选择一个顶点，读取当前影响物的权重作为强度": "Click, then select a vertex in the viewport to sample the current influence weight as the intensity.",
    "而不会包含来自附近顶点的影响物，防止周围权重扩散": "and exclude influences from nearby vertices to prevent weight spreading",
    "分配给其它影响物": "Distribute to other influences",
    "影响镜像映射": "Influence Mirror Mapping",
    "影响物": "Influences",
    "影响物排序 ( 按名称 )": "Show influences sorted",
    "影响物权重": "Influence weights",
    "影响物显示方式": "Influence display mode",
    "影响物限制:": "Influences limit:",
    "影响物映射": "Influences mapping",
    "选择对当前影响物具有非零权重的顶点": "Select vertices that have non-zero weight for current influence.",
    "选择受影响的顶点": "Select Affected Vertices",
    "在影响物列表中选择一个或多个影响影响物": "Select one or more influences in Influences list",
    "为每个影响物选择随机颜色，从Maya的索引颜色调色板中选择": "Choose random colors for each influence, selecting from Maya's pallete of indexed colors",
    "为所选图层中每个顶点的最接近影响物分配1.0权重": "Assign 1.0 weight for closest influence per each vertex in selected layer",
    "显示设置": "Display settings",
    "显示原本模型": "Show Original Mesh",
    "双四元权重": "Dual quaternion weights",
    "双四元数权重": "Dual quaternion weights",
    "图层蒙板": "Layer mask",
    "图层遮罩": "Layer mask",
    "图层切换: %r": "layers toggled: %r",
    "设置当前图层为 %r 上的 %r": "setting current layer to %r on %r",
    "初始化蒙皮图层": "Initialize Skinning Layers",
    "创建图层": "Create layer",
    "删除所有网格的Ng节点": "Delete All Custom Nodes",
    "删除选中网格的Ng节点": "Delete Custom Nodes For Selection",
    "当前场景中不包含任何Ng节点.": "The current scene contains no ngSkinTools nodes.",
    "当前选择不包含任何的Ng节点.": "The current selection contains no ngSkinTools nodes.",
    "这将会删除所有Ng节点.权重会保留，Ng图层会消失，确认删除么？": "This will delete all ngSkinTools nodes. Skin weights will remain, but ngSkinTools layers will be removed. Continue?",
    "这将会删除选中项的Ng节点.权重会保留，Ng图层会消失 确认删除么？": "This will delete ngSkinTools nodes from the selection. Skin weights will remain, but ngSkinTools layers will be removed. Continue?",
    "这个网格上有以前版本的ngSkinTools的皮肤层,这个操作将初始化.": "This mesh contains ngSkinTools layers from an older version. This operation will initialize it from scratch.",
    "从头开始蒙皮层，丢弃之前的层信息。你想继续吗?": "skinning layers from scratch, discarding previous layers information. Do you want to continue?",
    "目标没有蒙皮，且绑定记录中没有可用骨骼": "The target has no skinCluster, and the binding record contains no usable joints.",
    "请先选择带有 skinCluster 的网格。": "Select a mesh with a skinCluster first.",
    "请选择一个网格顶点，并确保当前图层已有绘制目标": "Select a mesh vertex and make sure the current layer has paint targets.",
    "整个选择的平均权重，忽略单独的壳或选择间隙": "average weights across whole selection, ignoring separate shells or selection gaps",
    "限制每个顶点的最大影响物": "Limit max influences per vertex",
    "仅更新当前shell.": "Only current shell will be updated.",
    "其它": "Other",
    "权重文件夹": "Weight folder",
    "导入方式": "Import method",
    "导入后处理": "After import",
    "顶点匹配": "Vertex matching",
    "批量导入导出": "Batch Import/Export",
    "按名称": "By name",
    "1对多": "One to many",
    "开始导入": "Start import",
    "导出所选": "Export selected",
    "检查更新...": "Check for Updates...",
    "ngSkinTools 已是最新版本。": "ngSkinTools is up to date.",
    "ngSkinTools切换到慢maya API设置皮肤集群权重为这个skinCluster，以解决玛雅bug时skinCluster使用dg节点作为输入.": "ngSkinTools switched to slow maya API for setting skin cluster weights for this skinCluster, to workaround a Maya bug when skinCluster uses dg nodes as inputs",
    "将所选模型的 ngSkinTools 权重导出到默认文件夹": "Export ngSkinTools weights for the selected models to the default folder.",
    "锁定全部蒙皮影响物": "Lock all skin influences",
    "解锁全部蒙皮影响物": "Unlock all skin influences",
    "锁定当前 skinCluster 中的全部影响物": "Lock all influences in the current skinCluster",
    "解锁当前 skinCluster 中的全部影响物": "Unlock all influences in the current skinCluster",
    "锁定当前未选中的蒙皮影响物": "Lock unselected skin influences",
    "解锁当前未选中的蒙皮影响物": "Unlock unselected skin influences",
    "搜索影响物名称，空格可输入多个关键词…": "Search influence names; separate multiple keywords with spaces…",
    "输入骨骼名称的一部分进行搜索。\n": "Enter part of a joint name to search.\n",
    "多个关键词用空格分隔，匹配任意一个关键词。\n": "Separate keywords with spaces; any matching keyword will be included.\n",
    "文件": "File",
    "图层": "Layers",
    "工具": "Tools",
    "查看": "View",
    "帮助": "Help",
    "语言": "Language",
    "简体中文": "简体中文",
    "切换界面语言为简体中文": "Switch the interface language to Simplified Chinese",
    "切换界面语言为英文": "Switch the interface language to English",
    "界面语言已切换": "Interface language changed",
})

_language = None
_language_listeners = []


def _text(value):
    try:
        text_type = unicode
    except NameError:
        text_type = str
    if isinstance(value, text_type):
        return value
    try:
        return value.decode("utf-8")
    except (AttributeError, UnicodeDecodeError):
        return value


def current_language():
    global _language
    if _language not in LANGUAGES:
        try:
            from ngSkinTools2.ui.options import config
            _language = config.ui_language()
        except Exception:
            _language = "zh_CN"
        if _language not in LANGUAGES:
            _language = "zh_CN"
    return _language


def tr(source, english=None):
    source = _text(source)
    if current_language() == "en_US":
        if english is not None:
            return _text(english)
        return _ENGLISH.get(source, source)
    return source


def register_language_listener(callback):
    if callback not in _language_listeners:
        _language_listeners.append(callback)


def unregister_language_listener(callback):
    try:
        _language_listeners.remove(callback)
    except ValueError:
        pass


def set_language(language):
    global _language
    if language not in LANGUAGES:
        raise ValueError("Unsupported UI language: {0}".format(language))
    if language == current_language():
        return False

    from ngSkinTools2.ui.options import config
    config.ui_language.set(language)
    _language = language
    for callback in list(_language_listeners):
        callback(language)
    return True
