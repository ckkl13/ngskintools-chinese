# -*- coding: UTF-8 -*-
"""Pure helpers for finding vertices affected by one influence."""

from numbers import Integral


def context_influence_id(item_id):
    """Return a numeric influence ID, excluding special tree rows."""
    if isinstance(item_id, Integral) and not isinstance(item_id, bool):
        return int(item_id)
    return None


def affected_vertex_indexes(layers, influence_id, threshold=0.00001):
    """Return sorted vertex indexes with weight above ``threshold``."""
    result = set()
    for layer in layers:
        weights = layer.get_weights(influence_id) or []
        result.update(
            index for index, weight in enumerate(weights) if weight > threshold
        )
    return sorted(result)
