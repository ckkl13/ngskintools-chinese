# -*- coding: UTF-8 -*-
"""
Pure influence-tree UI helpers.

This module intentionally avoids Maya and Qt imports so its state transitions
can be exercised outside Maya with small duck-typed test objects.
"""
from __future__ import unicode_literals

from ngSkinTools2.ui.i18n import tr

import time

def search_placeholder():
    return tr("搜索影响物名称，空格可输入多个关键词…")


def search_tooltip():
    return (
        tr("输入骨骼名称的一部分进行搜索。\n")
        + tr("多个关键词用空格分隔，匹配任意一个关键词。\n")
        + tr("* 表示任意字符，例如：leg_*。\n")
        + tr("点击右侧 × 清空搜索。")
    )


SEARCH_PLACEHOLDER = search_placeholder()
SEARCH_TOOLTIP = search_tooltip()


def expand_parent_chain(item):
    """Expand every ancestor of ``item`` without expanding the item itself."""
    parent = None if item is None else item.parent()
    while parent is not None:
        parent.setExpanded(True)
        parent = parent.parent()


def set_branch_expanded(item, expanded):
    """Recursively apply one expanded state to an item and its descendants."""
    if item is None:
        return

    items = [item]
    for current in items:
        for child_index in range(current.childCount()):
            items.append(current.child(child_index))

    # Expand parents first so Qt does not discard expansion state on hidden
    # descendants; collapse children first so the branch closes reliably.
    ordered = items if expanded else reversed(items)
    for current in ordered:
        current.setExpanded(expanded)


def descendant_items(items):
    """Return selected tree items and all descendants without duplicates."""
    result = []
    seen = set()
    pending = list(items or [])
    while pending:
        current = pending.pop(0)
        marker = id(current)
        if marker in seen:
            continue
        seen.add(marker)
        result.append(current)
        for child_index in range(current.childCount()):
            pending.append(current.child(child_index))
    return result


def is_recursive_toggle_request(button, modifiers, left_button, control_modifier, shift_modifier):
    """Return whether an input event requests recursive branch toggling."""
    required_modifiers = control_modifier | shift_modifier
    return button == left_button and (modifiers & required_modifiers) == required_modifiers


def is_branch_indicator_hit(x, depth, indentation, column_left=0):
    """Test whether a viewport x coordinate is inside an item's disclosure cell."""
    if indentation <= 0 or depth < 0:
        return False
    indicator_left = column_left + depth * indentation
    return indicator_left <= x < indicator_left + indentation


def reveal_item(view, item, scroll_hint, set_current=True):
    """Make an item current, reveal its ancestors, and center it in the view."""
    if item is None:
        return
    expand_parent_chain(item)
    if set_current:
        view.setCurrentItem(item)
    # Scroll using the influence-name column.  The lock column is intentionally
    # a separate fixed column, so scrolling the default column 0 would leave a
    # long hierarchy name off-screen even when the row itself is centered.
    column = 1 if view.columnCount() > 1 else 0
    index = view.indexFromItem(item, column)
    view._allow_reveal_scroll = True
    try:
        if index.isValid():
            view.scrollTo(index, scroll_hint)
        else:
            view.scrollToItem(item, scroll_hint)
    finally:
        view._allow_reveal_scroll = False

    # QTreeView treats PositionAtCenter as a visibility hint when the target
    # column is wider than the viewport.  Correct both axes explicitly so the
    # actual influence label, rather than the clipped cell, is centered.
    row = view.visualItemRect(item)
    viewport = view.viewport().rect()
    vertical_bar = view.verticalScrollBar()
    horizontal_bar = view.horizontalScrollBar()

    if row.isValid():
        vertical_value = vertical_bar.value() + row.center().y() - viewport.center().y()
        vertical_bar.setValue(
            max(vertical_bar.minimum(), min(vertical_value, vertical_bar.maximum()))
        )

        row = view.visualItemRect(item)
        cell = view.visualRect(index) if index.isValid() else row
        text_width = view.fontMetrics().width(item.text(column))
        icon_width = view.iconSize().width()
        if icon_width <= 0:
            icon_width = 16
        text_center = cell.x() + icon_width + 4 + text_width // 2
        frozen_width = view.columnWidth(0) if view.columnCount() > 1 else 0
        name_area_center = (frozen_width + viewport.width()) // 2
        horizontal_value = horizontal_bar.value() + text_center - name_area_center
        horizontal_bar.setValue(
            max(
                horizontal_bar.minimum(),
                min(horizontal_value, horizontal_bar.maximum()),
            )
        )


def first_existing_target(tree_items, paint_targets):
    """Return the first visible tree item following paint target order."""
    for target in paint_targets or []:
        if target in tree_items:
            return tree_items[target]
    return None


def filter_hierarchy_records(records, is_match):
    """
    Keep only name-matching records and connect them to matching ancestors.

    Non-matching Maya DAG parents are intentionally omitted. A matching record
    becomes a root row when none of its matching DAG ancestors are present.
    Special rows without searchable influence text, such as Mask and DQ, are
    also excluded while an influence-name search is active.
    """
    matched_records = [
        record
        for record in records
        if record.get("search_text") is not None
        and is_match(record["search_text"])
    ]
    matched_paths = set(
        record["dag_path"]
        for record in matched_records
        if record.get("dag_path")
    )

    result = []
    for record in matched_records:
        filtered_record = dict(record)
        parent_path = None
        dag_path = record.get("dag_path")
        if dag_path and "|" in dag_path:
            candidate = dag_path.rsplit("|", 1)[0]
            while candidate:
                if candidate in matched_paths:
                    parent_path = candidate
                    break
                candidate = candidate.rsplit("|", 1)[0]
        filtered_record["search_parent_path"] = parent_path
        result.append(filtered_record)
    return result


def prepare_display_records(records, hierarchy_enabled, is_match=None):
    """
    Prepare influence rows for hierarchical or original flat presentation.

    ``display_parent_path`` is always explicit so the Qt builder does not need
    to infer a parent in flat mode. Search excludes special non-influence rows
    in both modes.
    """
    if is_match is not None:
        if hierarchy_enabled:
            result = filter_hierarchy_records(records, is_match)
        else:
            result = [
                dict(record)
                for record in records
                if record.get("search_text") is not None
                and is_match(record["search_text"])
            ]
    else:
        result = [dict(record) for record in records]

    for record in result:
        if hierarchy_enabled:
            record["display_parent_path"] = record.get("search_parent_path")
        else:
            record["display_parent_path"] = None
    return result


def apply_expansion_policy(view, hierarchy_items, had_items, filter_text, expanded_keys):
    """
    Expand all only while searching; otherwise preserve or start collapsed.

    The current target's ancestor chain is revealed separately by
    ``reveal_item`` so unrelated skeleton branches remain collapsed.
    """
    if filter_text:
        view.expandAll()
        return

    if not had_items:
        return

    for hierarchy_key, item in hierarchy_items.items():
        item.setExpanded(hierarchy_key in expanded_keys)


class SampleInfluenceRevealState(object):
    """Track sample-influence presses and one delayed change notification."""

    RELEASE_GRACE_SECONDS = 0.5

    def __init__(self):
        self.active = False
        self._changed_while_active = False
        self._pending_until = 0

    def begin(self):
        self.active = True
        self._changed_while_active = False
        self._pending_until = 0

    def end(self):
        if self.active and not self._changed_while_active:
            self._pending_until = time.time() + self.RELEASE_GRACE_SECONDS
        self.active = False
        self._changed_while_active = False

    def cancel(self):
        self.active = False
        self._changed_while_active = False
        self._pending_until = 0

    def should_reveal(self):
        if self.active:
            self._changed_while_active = True
            return True

        if self._pending_until and time.time() <= self._pending_until:
            self._pending_until = 0
            return True

        self._pending_until = 0
        return False


sample_influence_reveal_state = SampleInfluenceRevealState()


def resolve_unique_dag_paths(raw_paths, long_matches):
    """
    Resolve each raw path from one batch ``cmds.ls(..., long=True)`` result.

    Ambiguous short names intentionally resolve to ``None`` so callers can keep
    those influences as independent root rows instead of merging them.
    """
    matches = list(long_matches or [])
    result = []
    for raw_path in raw_paths:
        if not raw_path:
            result.append(None)
            continue
        if raw_path in matches:
            result.append(raw_path)
            continue

        suffix = "|" + raw_path.lstrip("|")
        candidates = [candidate for candidate in matches if candidate.endswith(suffix)]
        result.append(candidates[0] if len(candidates) == 1 else None)
    return result


def drop_duplicate_dag_paths(paths):
    """Demote every repeated DAG path so no logical influence is overwritten."""
    counts = {}
    for path in paths:
        if path is not None:
            counts[path] = counts.get(path, 0) + 1
    return [path if path is None or counts[path] == 1 else None for path in paths]


class SearchTransition(object):
    """Store one pre-search snapshot until search is cleared or invalidated."""

    def __init__(self):
        self.snapshot = None

    def enter(self, text, snapshot):
        if text and self.snapshot is None:
            self.snapshot = snapshot
        return self.snapshot

    def leave(self, text):
        if text or self.snapshot is None:
            return None
        snapshot = self.snapshot
        self.snapshot = None
        return snapshot

    def clear(self):
        self.snapshot = None


class TreeSnapshot(object):
    """Serializable values needed to restore the influence tree after search."""

    def __init__(self, skin_cluster, layer_id, expanded_keys, scroll_value, current_id, selected_ids, paint_targets):
        self.skin_cluster = skin_cluster
        self.layer_id = layer_id
        self.expanded_keys = set(expanded_keys)
        self.scroll_value = scroll_value
        self.current_id = current_id
        self.selected_ids = list(selected_ids)
        self.paint_targets = list(paint_targets)

    def matches(self, skin_cluster, layer_id):
        return self.skin_cluster == skin_cluster and self.layer_id == layer_id


def capture_tree_snapshot(view, hierarchy_items, get_item_id, skin_cluster, layer_id, paint_targets):
    """Capture stable IDs and values instead of short-lived Qt item objects."""
    expanded_keys = set(
        hierarchy_key for hierarchy_key, item in hierarchy_items.items() if item.isExpanded()
    )
    selected_ids = []
    for item in view.selectedItems():
        item_id = get_item_id(item)
        if item_id is not None:
            selected_ids.append(item_id)

    return TreeSnapshot(
        skin_cluster=skin_cluster,
        layer_id=layer_id,
        expanded_keys=expanded_keys,
        scroll_value=view.verticalScrollBar().value(),
        current_id=get_item_id(view.currentItem()),
        selected_ids=selected_ids,
        paint_targets=paint_targets or [],
    )


def restore_tree_snapshot(view, hierarchy_items, tree_items, snapshot):
    """
    Restore tree widgets and return paint targets that still exist in the tree.

    Signal blocking remains the caller's responsibility because the real Qt
    owner already provides a project-specific context manager for it.
    """
    for hierarchy_key, item in hierarchy_items.items():
        item.setExpanded(hierarchy_key in snapshot.expanded_keys)

    selected_ids = set(snapshot.selected_ids)
    for item_id, item in tree_items.items():
        item.setSelected(item_id in selected_ids)

    current_item = tree_items.get(snapshot.current_id)
    if current_item is not None:
        view.setCurrentItem(current_item)

    view.verticalScrollBar().setValue(snapshot.scroll_value)
    return [item_id for item_id in snapshot.paint_targets if item_id in tree_items]
